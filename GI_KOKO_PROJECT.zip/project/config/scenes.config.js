// config/scenes.config.js
module.exports = [
  { id: 1, name: 'THE MYSTERIOUS MAP',   start: 0,   end: 35,  frames: { start: 0,    end: 840  } },
  { id: 2, name: 'THE CRAZY SHIP',       start: 35,  end: 70,  frames: { start: 840,  end: 1680 } },
  { id: 3, name: 'THE SEA MONSTER',      start: 70,  end: 110, frames: { start: 1680, end: 2640 } },
  { id: 4, name: 'THE LOST ISLAND',      start: 110, end: 150, frames: { start: 2640, end: 3600 } },
  { id: 5, name: 'THE TRAP MAZE',        start: 150, end: 190, frames: { start: 3600, end: 4560 } },
  { id: 6, name: 'THE GOLDEN BANANA',    start: 190, end: 235, frames: { start: 4560, end: 5640 } },
  { id: 7, name: 'THE FINAL CHAOS',      start: 235, end: 275, frames: { start: 5640, end: 6600 } },
  { id: 8, name: 'THE UNEXPECTED ENDING',start: 275, end: 300, frames: { start: 6600, end: 7200 } },
];
