// config/audio.config.js
module.exports = {
  tts: {
    provider: 'deepgram',
    apiUrl: 'https://api.deepgram.com/v1/speak',
    voices: {
      captain:  'aura-2-atlas-en',
      bobby:    'aura-2-aries-en',
      parrot:   'aura-2-hermes-en',
      monster:  'aura-2-draco-en',
      narrator: 'aura-2-athena-en',
    },
    encoding: 'mp3',
    sampleRate: 24000,
  },
  music: {
    volume: 0.15,
    fadeIn: 2,
    fadeOut: 2,
  },
  sfx: {
    volume: 0.3,
  },
  dialogue: {
    volume: 1.0,
  },
  output: {
    sampleRate: 44100,
    channels: 2,
    format: 'aac',
  },
};
