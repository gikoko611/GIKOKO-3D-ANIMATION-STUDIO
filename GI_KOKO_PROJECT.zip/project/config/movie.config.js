// config/movie.config.js
module.exports = {
  title: 'THE CURSED GOLDEN BANANA',
  brand: 'G.I KO KO STUDIO POWERED BY I KO KO',
  width: 360,
  height: 640,
  fps: 24,
  duration: 300, // seconds
  totalFrames: 7200,
  aspectRatio: '9:16',
  output: {
    dir: 'output',
    video: 'GI_KOKO_PIRATE_ADVENTURE.mp4',
    srt: 'GI_KOKO_PIRATE_ADVENTURE.srt',
    audioMix: 'final_mix.aac',
  },
  codec: {
    video: 'libx264',
    audio: 'aac',
    pixelFormat: 'yuv420p',
  },
};
