#!/usr/bin/env python3
"""Write all JS source modules for GI KOKO Pirate Adventure."""
import os

def w(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.strip() + '\n')
    print(f"  ✓ {path}")

# ── src/utils/logger.js ──
w('src/utils/logger.js', """
const winston = require('winston');
const fs = require('fs-extra');
fs.ensureDirSync('output');
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'HH:mm:ss' }),
    winston.format.printf(({ timestamp, level, message }) => `[${timestamp}] ${level.toUpperCase()}: ${message}`)
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'output/render.log', level: 'debug' }),
  ],
});
function progress(pct, msg) {
  const bar = '█'.repeat(Math.floor(pct / 5)) + '░'.repeat(20 - Math.floor(pct / 5));
  logger.info(`[${String(pct).padStart(3)}%] ${bar} ${msg}`);
}
module.exports = { logger, progress };
""")

# ── src/utils/validation.js ──
w('src/utils/validation.js', """
const { execSync } = require('child_process');
const fs = require('fs-extra');
const { logger } = require('./logger');
const movieConfig = require('../../config/movie.config');

function validateOutput(filePath) {
  logger.info('Validating output video...');
  if (!fs.existsSync(filePath)) throw new Error('Output file not found: ' + filePath);
  const stat = fs.statSync(filePath);
  if (stat.size < 100000) throw new Error('Output file too small: ' + stat.size);
  const probe = execSync(`ffprobe -v quiet -print_format json -show_format -show_streams "${filePath}"`, { encoding: 'utf-8' });
  const info = JSON.parse(probe);
  const vs = info.streams.find(s => s.codec_type === 'video');
  const as = info.streams.find(s => s.codec_type === 'audio');
  if (!vs) throw new Error('No video stream found');
  if (!as) throw new Error('No audio stream found');
  const dur = parseFloat(info.format.duration);
  if (Math.abs(dur - movieConfig.duration) > 5) throw new Error('Duration mismatch: ' + dur.toFixed(1));
  logger.info('✅ Validation passed: ' + dur.toFixed(1) + 's ' + vs.width + 'x' + vs.height + ' ' + vs.codec_name + '/' + as.codec_name);
  return { duration: dur, width: parseInt(vs.width), height: parseInt(vs.height), videoCodec: vs.codec_name, audioCodec: as.codec_name, fileSize: stat.size };
}
module.exports = { validateOutput };
""")

# ── src/renderer/three-renderer.js ──
w('src/renderer/three-renderer.js', r"""
// Headless Three.js renderer using 'gl' (headless-gl)
const createContext = require('gl');
const { createCanvas } = require('canvas');

// Polyfill document/window for Three.js
if (typeof document === 'undefined') {
  const _c = createCanvas(1,1);
  global.document = {
    createElement: (t) => { if(t==='canvas'){const c=createCanvas(1,1);c.addEventListener=()=>{};c.removeEventListener=()=>{};return c;} return {style:{}}; },
    createElementNS: (n,t) => { if(t==='canvas'){const c=createCanvas(1,1);c.addEventListener=()=>{};c.removeEventListener=()=>{};return c;} return {style:{}}; },
    body: { appendChild:()=>{}, removeChild:()=>{} }
  };
  global.window = { innerWidth:360, innerHeight:640, addEventListener:()=>{}, removeEventListener:()=>{}, navigator:{userAgent:'node'}, document:global.document, URL:{createObjectURL:()=>''}, requestAnimationFrame:(cb)=>setTimeout(cb,16) };
  global.navigator = { userAgent:'node' };
  global.self = global.window;
  global.HTMLCanvasElement = _c.constructor;
}

const THREE = require('three');

class HeadlessRenderer {
  constructor(width, height) {
    this.width = width; this.height = height;
    this.gl = createContext(width, height, { preserveDrawingBuffer:true, antialias:false });
    if (!this.gl) throw new Error('Failed to create headless GL context');
    const canvas = createCanvas(width, height);
    canvas.addEventListener = ()=>{}; canvas.removeEventListener = ()=>{};
    canvas.getContext = (t) => (t.includes('webgl') ? this.gl : null);
    canvas.style = {}; canvas.width = width; canvas.height = height;
    this.renderer = new THREE.WebGLRenderer({ canvas, context:this.gl, antialias:false, preserveDrawingBuffer:true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(1);
    this.renderer.shadowMap.enabled = false;
    this.pixels = Buffer.alloc(width * height * 4);
  }
  render(scene, camera) { this.renderer.render(scene, camera); }
  getPixels() {
    this.gl.readPixels(0,0,this.width,this.height,this.gl.RGBA,this.gl.UNSIGNED_BYTE,this.pixels);
    const row = this.width*4; const flipped = Buffer.alloc(this.width*this.height*4);
    for(let y=0;y<this.height;y++) {
      const src=(this.height-1-y)*row; const dst=y*row;
      this.pixels.copy(flipped,dst,src,src+row);
    }
    return flipped;
  }
  dispose() {
    this.renderer.dispose();
    const ext = this.gl && this.gl.getExtension('STACKGL_destroy_context');
    if(ext) ext.destroy();
  }
}
module.exports = HeadlessRenderer;
""")

# ── src/renderer/frame-renderer.js ──
w('src/renderer/frame-renderer.js', """
const path = require('path');
const fs = require('fs-extra');
const { PNG } = require('pngjs');
const HeadlessRenderer = require('./three-renderer');
const { logger, progress } = require('../utils/logger');
const movieConfig = require('../../config/movie.config');
const scenesConfig = require('../../config/scenes.config');

class FrameRenderer {
  constructor() { this.width=movieConfig.width; this.height=movieConfig.height; this.fps=movieConfig.fps; this.totalFrames=movieConfig.totalFrames; }
  init() { logger.info('Initializing renderer '+this.width+'x'+this.height+'@'+this.fps+'fps'); this.renderer=new HeadlessRenderer(this.width,this.height); fs.ensureDirSync('temp/frames'); }
  renderAllFrames(sceneManager) {
    logger.info('Rendering '+this.totalFrames+' frames...');
    for(let frame=0; frame<this.totalFrames; frame++) {
      const time = frame/this.fps;
      const sc = scenesConfig.find(s=>time>=s.start&&time<s.end) || scenesConfig[scenesConfig.length-1];
      const {scene,camera} = sceneManager.getScene(sc.id,time,frame);
      this.renderer.render(scene,camera);
      const pixels = this.renderer.getPixels();
      const png = new PNG({width:this.width,height:this.height}); png.data=pixels;
      const buf = PNG.sync.write(png);
      fs.writeFileSync(path.join('temp/frames','frame_'+String(frame).padStart(5,'0')+'.png'),buf);
      if(frame%200===0||frame===this.totalFrames-1) progress(35+Math.floor(frame/this.totalFrames*45),'Frame '+(frame+1)+'/'+this.totalFrames+' Scene '+sc.id+': '+sc.name);
    }
    logger.info('All frames rendered');
  }
  dispose() { if(this.renderer) this.renderer.dispose(); }
}
module.exports = FrameRenderer;
""")

# ── src/renderer/video-encoder.js ──
w('src/renderer/video-encoder.js', """
const { execSync } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const { logger, progress } = require('../utils/logger');
const movieConfig = require('../../config/movie.config');

function encodeVideo(framesDir, audioPath, outputPath) {
  fs.ensureDirSync(path.dirname(outputPath));
  progress(90,'Encoding final MP4...');
  const hasAudio = audioPath && fs.existsSync(audioPath);
  let cmd = `ffmpeg -y -framerate ${movieConfig.fps} -i "${framesDir}/frame_%05d.png"`;
  if(hasAudio) cmd+=` -i "${audioPath}"`;
  cmd+=` -c:v ${movieConfig.codec.video} -preset fast -crf 23 -pix_fmt ${movieConfig.codec.pixelFormat}`;
  if(hasAudio) cmd+=` -c:a ${movieConfig.codec.audio} -b:a 128k -shortest`;
  cmd+=` -t ${movieConfig.duration} -movflags +faststart "${outputPath}"`;
  logger.info('Encoding: '+cmd);
  execSync(cmd,{stdio:'pipe',timeout:600000});
  const stat=fs.statSync(outputPath);
  logger.info('Encoded: '+outputPath+' ('+( stat.size/1024/1024).toFixed(2)+'MB)');
  return outputPath;
}

function burnSubtitles(inputPath, srtPath, outputPath) {
  progress(92,'Burning Myanmar subtitles...');
  if(!fs.existsSync(srtPath)){logger.warn('SRT not found, skipping burn');fs.copyFileSync(inputPath,outputPath);return outputPath;}
  const absPath = path.resolve(srtPath).replace(/\\\\/g,'/').replace(/:/g,'\\\\:');
  let cmd = `ffmpeg -y -i "${inputPath}" -vf "subtitles='${absPath}':force_style='FontName=Noto Sans Myanmar,FontSize=14,PrimaryColour=&HFFFFFF,OutlineColour=&H000000,Outline=2,MarginV=20,Alignment=2,Bold=1'" -c:v ${movieConfig.codec.video} -preset fast -crf 23 -c:a copy -pix_fmt ${movieConfig.codec.pixelFormat} -movflags +faststart "${outputPath}"`;
  try { execSync(cmd,{stdio:'pipe',timeout:600000}); logger.info('Subtitles burned: '+outputPath); }
  catch(e) { logger.warn('Subtitle burn failed: '+e.message); fs.copyFileSync(inputPath,outputPath); }
  return outputPath;
}
module.exports = { encodeVideo, burnSubtitles };
""")

# ── src/engine/scene-manager.js ──
w('src/engine/scene-manager.js', """
const THREE = require('three');
const { createCharacters } = require('../characters/all-characters');
const { createEnvironments } = require('../environments/all-environments');
const CameraManager = require('./camera-manager');
const LightingManager = require('./lighting');
const AnimationManager = require('./animation-manager');
const scenesConfig = require('../../config/scenes.config');
const { logger } = require('../utils/logger');

class SceneManager {
  constructor(w,h) { this.width=w; this.height=h; this.scenes={}; this.cam=new CameraManager(w,h); this.light=new LightingManager(); this.anim=new AnimationManager(); this.chars=createCharacters(); this.envs=createEnvironments(); }
  init() { logger.info('Building scenes...'); scenesConfig.forEach(sc=>{ const scene=new THREE.Scene(); scene.background=new THREE.Color(0x87CEEB); this.light.addTo(scene,sc.id); const env=this._getEnv(sc.id); if(env)scene.add(env); this._getChars(sc.id).forEach(c=>scene.add(c)); this.scenes[sc.id]=scene; }); logger.info('Scenes ready'); }
  _getEnv(id) { if(id<=2) return this.envs.ocean; if(id===3) return this.envs.ocean; if(id===4) return this.envs.island; if(id<=6) return this.envs.temple; if(id===8) return this.envs.sunset; return this.envs.temple; }
  _getChars(id) {
    const all=this.chars; const c=[];
    if(id<=2||id===4||id===5) { c.push(all.captain,all.bobby,all.parrot); }
    else if(id===3||id===7) { c.push(all.captain,all.bobby,all.parrot,all.monster); }
    else if(id===6) { c.push(all.captain,all.bobby,all.parrot,all.guardian); }
    else { c.push(all.captain,all.bobby,all.parrot,all.monster); }
    return c.map(ch=>{ const cl=ch.clone(); cl.userData={...ch.userData}; return cl; });
  }
  getScene(sceneId,time,frame) {
    const scene=this.scenes[sceneId]||this.scenes[1];
    const sc=scenesConfig.find(s=>s.id===sceneId)||scenesConfig[0];
    const lt=time-sc.start; const t=lt/(sc.end-sc.start);
    this.anim.update(scene,sceneId,lt,Math.max(0,Math.min(1,t)));
    const camera=this.cam.update(sceneId,lt,Math.max(0,Math.min(1,t)));
    return {scene,camera};
  }
}
module.exports = SceneManager;
""")

# ── src/engine/camera-manager.js ──
w('src/engine/camera-manager.js', """
const THREE = require('three');
class CameraManager {
  constructor(w,h) { this.camera=new THREE.PerspectiveCamera(50,w/h,0.1,1000); this.camera.position.set(0,2,8); this.camera.lookAt(0,1,0); }
  update(id,lt,t) {
    const c=this.camera;
    if(id===1){
      if(t<0.3){c.position.set(Math.sin(lt*.1)*2,3+Math.sin(lt*.2)*.3,10-t*5);c.lookAt(0,1,0);}
      else if(t<0.6){c.position.set(.5,2.2,3);c.lookAt(0,2,0);}
      else{c.position.set(Math.sin(lt*.3)*1.5,2.5,7);c.lookAt(0,1.5,0);}
    } else if(id===2){
      const sh=t>.5?Math.sin(lt*10)*.1:0; c.position.set(Math.sin(lt*.5)*3+sh,2.5+Math.cos(lt*.3)*.5,6+Math.sin(lt*.2)*2); c.lookAt(sh,1.5,0);
    } else if(id===3){
      if(t<.3){c.position.set(0,.5,8);c.lookAt(0,5,-5);}
      else if(t<.6){const a=lt*.3;c.position.set(Math.sin(a)*8,3,Math.cos(a)*8);c.lookAt(0,2,0);}
      else{c.position.set(Math.sin(lt)*3,4+Math.sin(lt*2)*2,5);c.lookAt(0,3,0);}
    } else if(id===4){
      if(t<.25){c.position.set(0,15,15);c.lookAt(0,0,0);}
      else if(t<.5){const d=(t-.25)/.25;c.position.set(Math.sin(lt*.2)*5,15-d*12,15-d*8);c.lookAt(0,1,0);}
      else{c.position.set(-3+t*6,2,5);c.lookAt(t*2,1.5,0);}
    } else if(id===5){
      const sh=Math.sin(lt*15)*.05*t; c.position.set(Math.sin(lt*.8)*4+sh,2+Math.abs(Math.sin(lt*2))*1.5,5+Math.sin(lt*.3)*3); c.lookAt(sh,1.5,0);
    } else if(id===6){
      if(t<.3){c.position.set(0,2,8-t*10);c.lookAt(0,2,-2);}
      else if(t<.6){c.position.set(2,.5,5);c.lookAt(-1,3,0);}
      else{const a=lt*.2;c.position.set(Math.sin(a)*5,2,Math.cos(a)*5);c.lookAt(0,2,0);}
    } else if(id===7){
      const sh=Math.sin(lt*20)*.15; c.position.set(Math.sin(lt*1.5)*5+sh,2.5+sh,4+Math.sin(lt*.5)*4); c.lookAt(sh,1.5+sh,0);
    } else {
      if(t<.6){const a=lt*.15;c.position.set(Math.sin(a)*7,2.5,Math.cos(a)*7);c.lookAt(0,1.5,0);}
      else{c.position.set(0,3+t*5,10+t*5);c.lookAt(0,1,0);}
    }
    return c;
  }
}
module.exports = CameraManager;
""")

# ── src/engine/lighting.js ──
w('src/engine/lighting.js', """
const THREE = require('three');
class LightingManager {
  addTo(scene,id) {
    scene.add(new THREE.AmbientLight(0xffffff,.4));
    scene.add(new THREE.HemisphereLight(0x87CEEB,0x443322,.3));
    if(id<=2){ const s=new THREE.DirectionalLight(0xFFD700,1.0); s.position.set(5,10,5); scene.add(s); }
    else if(id===3){ const s=new THREE.DirectionalLight(0x8899AA,.6); s.position.set(3,8,3); scene.add(s); scene.add(Object.assign(new THREE.PointLight(0x4466AA,.4,20),{position:new THREE.Vector3(0,5,0)})); }
    else if(id===4){ const s=new THREE.DirectionalLight(0xFFDD44,1.2); s.position.set(5,12,5); scene.add(s); }
    else if(id<=6){ scene.background=new THREE.Color(0x1a1a2e); [[-3,3,2],[3,3,-2]].forEach(([x,y,z])=>{const l=new THREE.PointLight(0xFF6600,.8,10);l.position.set(x,y,z);scene.add(l);}); scene.add(Object.assign(new THREE.PointLight(0xFFD700,.6,8),{position:new THREE.Vector3(0,2,-3)})); }
    else if(id===7){ scene.background=new THREE.Color(0x2a1a0a); const r=new THREE.PointLight(0xFF3300,1.0,15); r.position.set(0,5,0); scene.add(r); }
    else { scene.background=new THREE.Color(0xFF7744); const s=new THREE.DirectionalLight(0xFF8833,1.0); s.position.set(-5,3,5); scene.add(s); }
  }
}
module.exports = LightingManager;
""")

# ── src/engine/animation-manager.js ──
w('src/engine/animation-manager.js', """
const THREE = require('three');
class AnimationManager {
  update(scene,id,lt,t) {
    scene.traverse(child => {
      if(!child.userData||!child.userData.type) return;
      const type=child.userData.type;
      if(type==='captain') this._captain(child,id,lt,t);
      else if(type==='bobby') this._bobby(child,id,lt,t);
      else if(type==='parrot') this._parrot(child,lt);
      else if(type==='monster') this._monster(child,lt,t);
      else if(type==='guardian') this._guardian(child,lt);
      else if(type==='ocean') this._ocean(child,lt);
      else if(type==='ship') this._ship(child,lt);
    });
  }
  _captain(g,id,lt,t) {
    g.position.y=(g.userData.baseY||0)+Math.sin(lt*2)*.05;
    const h=g.getObjectByName('head'); if(h){h.rotation.y=Math.sin(lt*1.5)*.2;h.rotation.x=Math.sin(lt*.8)*.05;}
    const la=g.getObjectByName('leftArm'),ra=g.getObjectByName('rightArm');
    if(la)la.rotation.x=Math.sin(lt*3)*.3; if(ra)ra.rotation.x=Math.sin(lt*3+Math.PI)*.3;
    const ll=g.getObjectByName('leftLeg'),rl=g.getObjectByName('rightLeg');
    if(ll)ll.rotation.x=Math.sin(lt*3)*.25; if(rl)rl.rotation.x=Math.sin(lt*3+Math.PI)*.25;
    if(id===3&&t>.6){g.position.y=3+Math.sin(lt*2)*2;g.rotation.z=Math.sin(lt*3)*.5;}
    if(id===7){g.position.x=-3+t*6; if(ll)ll.rotation.x=Math.sin(lt*8)*.5; if(rl)rl.rotation.x=Math.sin(lt*8+Math.PI)*.5;}
  }
  _bobby(g,id,lt,t) {
    g.position.y=(g.userData.baseY||0)+Math.sin(lt*2.5)*.05;
    const h=g.getObjectByName('head'); if(h){h.rotation.y=Math.sin(lt*2)*.3;h.rotation.z=Math.sin(lt*1.5)*.1;}
    const la=g.getObjectByName('leftArm'),ra=g.getObjectByName('rightArm');
    if(la)la.rotation.x=Math.sin(lt*3.5)*.4; if(ra)ra.rotation.x=Math.sin(lt*3.5+Math.PI)*.4;
    const ll=g.getObjectByName('leftLeg'),rl=g.getObjectByName('rightLeg');
    if(ll)ll.rotation.x=Math.sin(lt*3.5)*.3; if(rl)rl.rotation.x=Math.sin(lt*3.5+Math.PI)*.3;
    if(id===7) g.position.x=-2+t*5;
  }
  _parrot(g,lt) {
    g.position.y=(g.userData.baseY||3)+Math.sin(lt*3)*.3;
    g.position.x=(g.userData.baseX||0)+Math.sin(lt*1.2)*1;
    const lw=g.getObjectByName('leftWing'),rw=g.getObjectByName('rightWing');
    if(lw)lw.rotation.z=Math.sin(lt*8)*.5; if(rw)rw.rotation.z=-Math.sin(lt*8)*.5;
  }
  _monster(g,lt,t) {
    const sc=1+Math.sin(lt*1.5)*.03; g.scale.set(sc,sc,sc);
    g.position.y=(g.userData.baseY||0)+Math.sin(lt*.8)*.3;
  }
  _guardian(g,lt) {
    g.position.y=(g.userData.baseY||0)+Math.sin(lt)*.2;
    g.rotation.y=lt*.3; const p=1+Math.sin(lt*2)*.05; g.scale.set(p,p,p);
  }
  _ocean(mesh,lt) {
    const pos=mesh.geometry&&mesh.geometry.attributes&&mesh.geometry.attributes.position; if(!pos) return;
    const bp=mesh.userData.basePositions; if(!bp) return;
    for(let i=0;i<pos.count;i++){const bx=bp[i*3];const bz=bp[i*3+2];pos.setY(i,Math.sin(bx*.5+lt*1.5)*.3+Math.cos(bz*.3+lt)*.2);}
    pos.needsUpdate=true;
  }
  _ship(g,lt) { g.rotation.z=Math.sin(lt*.8)*.05; g.rotation.x=Math.sin(lt*.6)*.03; g.position.y=(g.userData.baseY||.5)+Math.sin(lt*1.2)*.15; }
}
module.exports = AnimationManager;
""")

print("✅ All JS source files written successfully")
