// src/renderer/frame-renderer.js
// Renders frames for each scene and pipes raw pixels to FFmpeg
const path = require('path');
const fs = require('fs-extra');
const { PNG } = require('pngjs');
const HeadlessRenderer = require('./three-renderer');
const { logger, progress } = require('../utils/logger');
const movieConfig = require('../../config/movie.config');
const scenesConfig = require('../../config/scenes.config');

class FrameRenderer {
  constructor() {
    this.width = movieConfig.width;
    this.height = movieConfig.height;
    this.fps = movieConfig.fps;
    this.totalFrames = movieConfig.totalFrames;
    this.renderer = null;
  }

  init() {
    logger.info(`Initializing frame renderer: ${this.width}x${this.height} @ ${this.fps}fps`);
    this.renderer = new HeadlessRenderer(this.width, this.height);
    fs.ensureDirSync('temp/frames');
  }

  renderAllFrames(sceneManager) {
    const framesDir = 'temp/frames';
    fs.ensureDirSync(framesDir);

    logger.info(`Rendering ${this.totalFrames} frames...`);

    for (let frame = 0; frame < this.totalFrames; frame++) {
      const time = frame / this.fps;

      // Determine which scene we're in
      const sceneIdx = scenesConfig.findIndex(
        s => time >= s.start && time < s.end
      );
      const sceneConfig = sceneIdx >= 0 ? scenesConfig[sceneIdx] : scenesConfig[scenesConfig.length - 1];

      // Get current scene data
      const { scene, camera } = sceneManager.getScene(sceneConfig.id, time, frame);

      // Render the frame
      this.renderer.render(scene, camera);

      // Save frame as PNG
      const pixels = this.renderer.getPixels();
      const png = new PNG({ width: this.width, height: this.height });
      png.data = pixels;
      const buffer = PNG.sync.write(png);

      const framePath = path.join(framesDir, `frame_${String(frame).padStart(5, '0')}.png`);
      fs.writeFileSync(framePath, buffer);

      // Progress logging every 100 frames
      if (frame % 100 === 0 || frame === this.totalFrames - 1) {
        const pct = Math.floor(35 + (frame / this.totalFrames) * 45);
        progress(pct, `Rendered frame ${frame + 1}/${this.totalFrames} (Scene ${sceneConfig.id}: ${sceneConfig.name})`);
      }
    }

    logger.info(`All ${this.totalFrames} frames rendered to ${framesDir}`);
  }

  dispose() {
    if (this.renderer) {
      this.renderer.dispose();
    }
  }
}

module.exports = FrameRenderer;
