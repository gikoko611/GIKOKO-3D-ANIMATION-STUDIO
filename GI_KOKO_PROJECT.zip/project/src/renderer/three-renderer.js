// src/renderer/three-renderer.js
// Headless Three.js renderer using 'gl' (headless-gl) + 'canvas' for server-side rendering
const createContext = require('gl');
const { createCanvas } = require('canvas');
const THREE = require('three');

// Polyfill DOM globals needed by Three.js
if (typeof document === 'undefined') {
  const _canvas = createCanvas(1, 1);
  global.document = {
    createElement: (tag) => {
      if (tag === 'canvas') return createCanvas(1, 1);
      return { style: {} };
    },
    createElementNS: (ns, tag) => {
      if (tag === 'canvas') return createCanvas(1, 1);
      return { style: {} };
    },
    body: { appendChild: () => {}, removeChild: () => {} },
  };
  global.window = {
    innerWidth: 360,
    innerHeight: 640,
    addEventListener: () => {},
    removeEventListener: () => {},
    navigator: { userAgent: 'node' },
    document: global.document,
    URL: { createObjectURL: () => '' },
    requestAnimationFrame: (cb) => setTimeout(cb, 16),
  };
  global.navigator = { userAgent: 'node' };
  global.HTMLCanvasElement = _canvas.constructor;
  global.self = global.window;
}

class HeadlessRenderer {
  constructor(width, height) {
    this.width = width;
    this.height = height;

    // Create headless GL context
    this.glContext = createContext(width, height, {
      preserveDrawingBuffer: true,
      antialias: false,
    });
    if (!this.glContext) {
      throw new Error('Failed to create headless GL context');
    }

    // Create a fake canvas wrapper
    const canvas = createCanvas(width, height);
    canvas.addEventListener = () => {};
    canvas.removeEventListener = () => {};
    canvas.getContext = (type) => {
      if (type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl') {
        return this.glContext;
      }
      return null;
    };
    canvas.style = {};
    canvas.width = width;
    canvas.height = height;

    // Create Three.js WebGL renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas: canvas,
      context: this.glContext,
      antialias: false,
      alpha: false,
      preserveDrawingBuffer: true,
      powerPreference: 'low-power',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(1);
    this.renderer.shadowMap.enabled = false;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    // Pixel buffer for readback
    this.pixels = new Uint8Array(width * height * 4);
  }

  render(scene, camera) {
    this.renderer.render(scene, camera);
  }

  getPixels() {
    this.glContext.readPixels(
      0, 0, this.width, this.height,
      this.glContext.RGBA, this.glContext.UNSIGNED_BYTE,
      this.pixels
    );
    // Flip vertically (OpenGL is bottom-up)
    const rowSize = this.width * 4;
    const flipped = Buffer.alloc(this.width * this.height * 4);
    for (let y = 0; y < this.height; y++) {
      const srcRow = (this.height - 1 - y) * rowSize;
      const dstRow = y * rowSize;
      this.pixels.copy(flipped, dstRow, srcRow, srcRow + rowSize);
    }
    return flipped;
  }

  dispose() {
    this.renderer.dispose();
    if (this.glContext && this.glContext.getExtension) {
      const ext = this.glContext.getExtension('STACKGL_destroy_context');
      if (ext) ext.destroy();
    }
  }
}

module.exports = HeadlessRenderer;
