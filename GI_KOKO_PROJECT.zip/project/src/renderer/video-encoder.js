// src/renderer/video-encoder.js
// Encodes rendered frames + mixed audio into final MP4 using FFmpeg
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs-extra');
const { logger, progress } = require('../utils/logger');
const movieConfig = require('../../config/movie.config');

function encodeVideo(framesDir, audioPath, outputPath) {
  fs.ensureDirSync(path.dirname(outputPath));
  progress(90, 'Encoding final MP4...');

  const hasAudio = audioPath && fs.existsSync(audioPath);

  // Build FFmpeg command
  let cmd = `ffmpeg -y -framerate ${movieConfig.fps}`;
  cmd += ` -i "${framesDir}/frame_%05d.png"`;

  if (hasAudio) {
    cmd += ` -i "${audioPath}"`;
  }

  cmd += ` -c:v ${movieConfig.codec.video}`;
  cmd += ` -preset fast`;
  cmd += ` -crf 23`;
  cmd += ` -pix_fmt ${movieConfig.codec.pixelFormat}`;

  if (hasAudio) {
    cmd += ` -c:a ${movieConfig.codec.audio}`;
    cmd += ` -b:a 128k`;
    cmd += ` -shortest`;
  }

  cmd += ` -t ${movieConfig.duration}`;
  cmd += ` -movflags +faststart`;
  cmd += ` "${outputPath}"`;

  logger.info(`FFmpeg command: ${cmd}`);
  execSync(cmd, { stdio: 'pipe', timeout: 600000 });

  const stat = fs.statSync(outputPath);
  logger.info(`Video encoded: ${outputPath} (${(stat.size / 1024 / 1024).toFixed(2)} MB)`);
  return outputPath;
}

function burnSubtitles(inputPath, srtPath, outputPath) {
  progress(92, 'Burning Myanmar subtitles into video...');

  if (!fs.existsSync(srtPath)) {
    logger.warn('SRT file not found, skipping subtitle burn');
    fs.copyFileSync(inputPath, outputPath);
    return outputPath;
  }

  const fontDir = '/usr/share/fonts/truetype/noto';
  const fontName = 'NotoSansMyanmar';

  let cmd = `ffmpeg -y -i "${inputPath}"`;
  cmd += ` -vf "subtitles='${srtPath}':force_style='FontName=${fontName},FontSize=14,PrimaryColour=&HFFFFFF,OutlineColour=&H000000,Outline=2,MarginV=20,Alignment=2,Bold=1'"`;
  cmd += ` -c:v ${movieConfig.codec.video} -preset fast -crf 23`;
  cmd += ` -c:a copy`;
  cmd += ` -pix_fmt ${movieConfig.codec.pixelFormat}`;
  cmd += ` -movflags +faststart`;
  cmd += ` "${outputPath}"`;

  try {
    execSync(cmd, { stdio: 'pipe', timeout: 600000 });
    logger.info(`Subtitles burned: ${outputPath}`);
  } catch (err) {
    logger.warn(`Subtitle burn failed, using video without burned subtitles: ${err.message}`);
    fs.copyFileSync(inputPath, outputPath);
  }

  return outputPath;
}

module.exports = { encodeVideo, burnSubtitles };
