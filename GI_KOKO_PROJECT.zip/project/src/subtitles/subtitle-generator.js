// src/subtitles/subtitle-generator.js
// Generate Myanmar Unicode SRT subtitles
const fs = require('fs-extra');
const path = require('path');
const { logger, progress } = require('../utils/logger');
const dialogueConfig = require('../../config/dialogue.config');
const movieConfig = require('../../config/movie.config');

function generateSubtitles() {
  progress(30, 'Generating Myanmar Unicode subtitles...');

  const outputPath = path.join('output', movieConfig.output.srt);
  fs.ensureDirSync('output');

  let srt = '';

  dialogueConfig.forEach((line, index) => {
    const startTime = formatSrtTime(line.start);
    const endTime = formatSrtTime(line.end);

    srt += `${index + 1}\n`;
    srt += `${startTime} --> ${endTime}\n`;
    srt += `${line.mm}\n`;
    srt += `\n`;
  });

  fs.writeFileSync(outputPath, srt, 'utf-8');
  logger.info(`✅ Myanmar SRT generated: ${outputPath} (${dialogueConfig.length} entries)`);

  // Also generate English SRT for reference
  const enSrtPath = path.join('output', 'GI_KOKO_PIRATE_ADVENTURE_EN.srt');
  let enSrt = '';
  dialogueConfig.forEach((line, index) => {
    enSrt += `${index + 1}\n`;
    enSrt += `${formatSrtTime(line.start)} --> ${formatSrtTime(line.end)}\n`;
    enSrt += `${line.en}\n\n`;
  });
  fs.writeFileSync(enSrtPath, enSrt, 'utf-8');

  return outputPath;
}

function formatSrtTime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const ms = Math.round((seconds % 1) * 1000);
  return `${pad2(h)}:${pad2(m)}:${pad2(s)},${pad3(ms)}`;
}

function pad2(n) { return String(n).padStart(2, '0'); }
function pad3(n) { return String(n).padStart(3, '0'); }

module.exports = { generateSubtitles };
