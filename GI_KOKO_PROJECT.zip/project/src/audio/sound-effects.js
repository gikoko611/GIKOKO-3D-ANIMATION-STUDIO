// src/audio/sound-effects.js
// Procedural sound effects using FFmpeg
const { execSync } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const { logger } = require('../utils/logger');

function generateSoundEffects() {
  const sfxDir = 'temp/sfx';
  fs.ensureDirSync(sfxDir);
  logger.info('Generating procedural sound effects...');

  const effects = [
    { name: 'ocean_waves', expr: "0.15*sin(0.3*2*PI*t)*sin(200*2*PI*t+sin(0.5*2*PI*t)*100)", duration: 300 },
    { name: 'wind', expr: "0.08*(sin(0.2*2*PI*t)*sin(800*2*PI*t)+sin(0.15*2*PI*t)*sin(400*2*PI*t))", duration: 300 },
    { name: 'ship_creak', expr: "0.1*sin(2*2*PI*t)*sin(150*2*PI*t)*exp(-2*mod(t,1))", duration: 70 },
    { name: 'splash', expr: "0.3*exp(-3*t)*sin(500*2*PI*t+sin(10*2*PI*t)*200)", duration: 2 },
    { name: 'explosion', expr: "0.4*exp(-2*t)*(sin(80*2*PI*t)+0.5*sin(120*2*PI*t))", duration: 3 },
    { name: 'monster_roar', expr: "0.3*sin(80*2*PI*t+sin(5*2*PI*t)*30)*exp(-0.5*t)", duration: 3 },
    { name: 'sneeze', expr: "0.4*exp(-8*(t-0.3)*(t-0.3))*(sin(300*2*PI*t)+sin(500*2*PI*t))", duration: 1 },
    { name: 'comedy_impact', expr: "0.5*exp(-10*t)*sin(200*2*PI*t)", duration: 1 },
    { name: 'treasure_glow', expr: "0.1*sin(880*2*PI*t)*sin(3*2*PI*t)+0.05*sin(1320*2*PI*t)", duration: 5 },
    { name: 'footsteps', expr: "0.2*exp(-20*mod(t,0.5))*sin(100*2*PI*t)", duration: 10 },
    { name: 'boulder_roll', expr: "0.2*sin(50*2*PI*t+sin(2*2*PI*t)*20)+0.1*sin(80*2*PI*t)", duration: 5 },
    { name: 'parrot_squawk', expr: "0.3*sin(1200*2*PI*t+sin(8*2*PI*t)*500)*exp(-3*mod(t,0.5))", duration: 2 },
    { name: 'magic_sparkle', expr: "0.15*(sin(2000*2*PI*t)*exp(-5*mod(t,0.3))+sin(3000*2*PI*t)*exp(-5*mod(t+0.15,0.3)))", duration: 3 },
    { name: 'temple_rumble', expr: "0.3*sin(40*2*PI*t+sin(1*2*PI*t)*10)+0.15*sin(60*2*PI*t)", duration: 10 },
  ];

  for (const fx of effects) {
    const outputFile = path.join(sfxDir, `${fx.name}.wav`);
    try {
      execSync(
        `ffmpeg -y -f lavfi -i "aevalsrc='${fx.expr}':s=44100:d=${fx.duration}" -c:a pcm_s16le "${outputFile}"`,
        { stdio: 'pipe', timeout: 30000 }
      );
      logger.info(`✓ SFX: ${fx.name} (${fx.duration}s)`);
    } catch (err) {
      logger.warn(`SFX failed for ${fx.name}: ${err.message}`);
      execSync(
        `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=mono -t ${fx.duration} -c:a pcm_s16le "${outputFile}"`,
        { stdio: 'pipe' }
      );
    }
  }

  logger.info('Sound effects generated.');
  return sfxDir;
}

module.exports = { generateSoundEffects };
