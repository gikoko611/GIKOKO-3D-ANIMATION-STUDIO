// src/audio/music.js
// Procedural background music generator using FFmpeg sine waves
const { execSync } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const { logger } = require('../utils/logger');
const scenesConfig = require('../../config/scenes.config');

function generateMusic() {
  const musicDir = 'temp/music';
  fs.ensureDirSync(musicDir);
  logger.info('Generating procedural background music...');

  const sceneMusic = [
    { id: 1, notes: [392, 440, 494, 523], tempo: 2, name: 'adventure_intro' },
    { id: 2, notes: [523, 587, 659, 698], tempo: 3, name: 'crazy_ship' },
    { id: 3, notes: [262, 294, 330, 262], tempo: 1.5, name: 'monster_theme' },
    { id: 4, notes: [523, 587, 659, 784], tempo: 2, name: 'island_paradise' },
    { id: 5, notes: [330, 370, 415, 466], tempo: 4, name: 'temple_tension' },
    { id: 6, notes: [440, 554, 659, 880], tempo: 2, name: 'treasure_reveal' },
    { id: 7, notes: [494, 587, 659, 784], tempo: 5, name: 'chaos_escape' },
    { id: 8, notes: [392, 494, 587, 784], tempo: 1.5, name: 'sunset_ending' },
  ];

  for (const sm of sceneMusic) {
    const sc = scenesConfig.find(s => s.id === sm.id);
    if (!sc) continue;
    const duration = sc.end - sc.start;
    const outputFile = path.join(musicDir, `${sm.name}.wav`);

    // Build multi-tone sine wave with harmonics
    const toneExpr = sm.notes.map((freq, i) => {
      const vol = 0.08 / (i + 1); // decreasing volume per harmonic
      return `${vol}*sin(${freq}*2*PI*t)`;
    }).join('+');

    // Add a rhythmic element
    const rhythm = `0.03*sin(${sm.tempo}*2*PI*t)*sin(100*2*PI*t)`;

    const expr = `${toneExpr}+${rhythm}`;

    try {
      execSync(
        `ffmpeg -y -f lavfi -i "aevalsrc='${expr}':s=44100:d=${duration}" -c:a pcm_s16le "${outputFile}"`,
        { stdio: 'pipe', timeout: 30000 }
      );
      logger.info(`✓ Music: ${sm.name} (${duration}s)`);
    } catch (err) {
      logger.warn(`Music generation failed for ${sm.name}: ${err.message}`);
      // Create silent track
      execSync(
        `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=stereo -t ${duration} -c:a pcm_s16le "${outputFile}"`,
        { stdio: 'pipe' }
      );
    }
  }

  logger.info('Background music generated.');
  return musicDir;
}

module.exports = { generateMusic };
