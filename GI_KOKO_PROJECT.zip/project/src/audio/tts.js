// src/audio/tts.js
// Deepgram Aura-2 TTS voice generation
const fetch = require('node-fetch');
const fs = require('fs-extra');
const path = require('path');
const { logger, progress } = require('../utils/logger');
const audioConfig = require('../../config/audio.config');
const dialogueConfig = require('../../config/dialogue.config');

async function generateAllVoices() {
  const apiKey = process.env.DEEPGRAM_API_KEY;
  if (!apiKey) {
    throw new Error('DEEPGRAM_API_KEY not set! Add it to GitHub Secrets.');
  }

  const voiceDir = 'temp/voices';
  fs.ensureDirSync(voiceDir);

  logger.info(`Generating ${dialogueConfig.length} voice lines with Deepgram Aura-2...`);

  for (let i = 0; i < dialogueConfig.length; i++) {
    const line = dialogueConfig[i];
    const voiceModel = audioConfig.tts.voices[line.character] || audioConfig.tts.voices.narrator;
    const outputFile = path.join(voiceDir, `voice_${String(line.id).padStart(3, '0')}.mp3`);

    // Skip if already generated (resume support)
    if (fs.existsSync(outputFile) && fs.statSync(outputFile).size > 100) {
      logger.info(`Voice ${line.id} already exists, skipping.`);
      continue;
    }

    try {
      const response = await fetch(
        `${audioConfig.tts.apiUrl}?model=${voiceModel}&encoding=mp3`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Token ${apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ text: line.en }),
        }
      );

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Deepgram API error ${response.status}: ${errText}`);
      }

      const buffer = await response.buffer();
      fs.writeFileSync(outputFile, buffer);
      logger.info(`✓ Voice ${line.id}/${dialogueConfig.length}: [${line.character}] "${line.en.substring(0, 50)}..." (${voiceModel})`);
    } catch (err) {
      logger.error(`✗ Voice ${line.id} failed: ${err.message}`);
      // Create a silent placeholder so pipeline doesn't break
      await createSilentAudio(outputFile, line.end - line.start);
    }

    // Rate limiting: Deepgram allows ~100 req/s but let's be safe
    await sleep(150);

    if (i % 10 === 0) {
      progress(20 + Math.floor((i / dialogueConfig.length) * 10), `Generated ${i + 1}/${dialogueConfig.length} voices`);
    }
  }

  logger.info(`All ${dialogueConfig.length} voice lines generated.`);
  return voiceDir;
}

async function createSilentAudio(outputFile, durationSec) {
  const { execSync } = require('child_process');
  try {
    execSync(
      `ffmpeg -y -f lavfi -i anullsrc=r=24000:cl=mono -t ${durationSec} -c:a libmp3lame -q:a 9 "${outputFile}"`,
      { stdio: 'pipe' }
    );
  } catch (e) {
    logger.warn(`Could not create silent audio placeholder: ${e.message}`);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = { generateAllVoices };
