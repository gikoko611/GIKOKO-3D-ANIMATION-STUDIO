// src/audio/mixer.js
// Mix all audio: dialogue + music + SFX into one AAC track
const { execSync } = require('child_process');
const fs = require('fs-extra');
const path = require('path');
const { logger, progress } = require('../utils/logger');
const dialogueConfig = require('../../config/dialogue.config');
const scenesConfig = require('../../config/scenes.config');
const movieConfig = require('../../config/movie.config');

function mixAllAudio() {
  progress(85, 'Mixing all audio...');
  const outputDir = 'temp/audio';
  fs.ensureDirSync(outputDir);

  // 1. Create dialogue timeline
  const dialogueMixed = path.join(outputDir, 'dialogue_timeline.wav');
  _mixDialogueTimeline(dialogueMixed);

  // 2. Create music timeline
  const musicMixed = path.join(outputDir, 'music_timeline.wav');
  _mixMusicTimeline(musicMixed);

  // 3. Create SFX timeline
  const sfxMixed = path.join(outputDir, 'sfx_timeline.wav');
  _mixSfxTimeline(sfxMixed);

  // 4. Final mix
  const finalMix = path.join('output', 'final_mix.aac');
  fs.ensureDirSync('output');

  let cmd = `ffmpeg -y`;
  const inputs = [];

  if (fs.existsSync(dialogueMixed)) { cmd += ` -i "${dialogueMixed}"`; inputs.push('dialogue'); }
  if (fs.existsSync(musicMixed))    { cmd += ` -i "${musicMixed}"`; inputs.push('music'); }
  if (fs.existsSync(sfxMixed))      { cmd += ` -i "${sfxMixed}"`; inputs.push('sfx'); }

  if (inputs.length === 0) {
    // Create silent audio track
    logger.warn('No audio tracks found, creating silent track');
    execSync(
      `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=stereo -t ${movieConfig.duration} -c:a aac -b:a 128k "${finalMix}"`,
      { stdio: 'pipe' }
    );
    return finalMix;
  }

  // Build amix filter
  const volumes = inputs.map(t => {
    switch (t) {
      case 'dialogue': return 1.0;
      case 'music': return 0.15;
      case 'sfx': return 0.3;
      default: return 0.5;
    }
  });

  if (inputs.length === 1) {
    cmd += ` -c:a aac -b:a 128k -t ${movieConfig.duration} "${finalMix}"`;
  } else {
    const filterParts = inputs.map((_, i) => `[${i}]volume=${volumes[i]}[a${i}]`).join(';');
    const mixInputs = inputs.map((_, i) => `[a${i}]`).join('');
    cmd += ` -filter_complex "${filterParts};${mixInputs}amix=inputs=${inputs.length}:duration=first:dropout_transition=3[out]"`;
    cmd += ` -map "[out]" -c:a aac -b:a 128k -t ${movieConfig.duration} "${finalMix}"`;
  }

  try {
    execSync(cmd, { stdio: 'pipe', timeout: 300000 });
    logger.info(`✅ Final audio mix: ${finalMix}`);
  } catch (err) {
    logger.error(`Audio mix failed: ${err.message}`);
    // Fallback: use dialogue only or silent
    if (fs.existsSync(dialogueMixed)) {
      execSync(`ffmpeg -y -i "${dialogueMixed}" -c:a aac -b:a 128k -t ${movieConfig.duration} "${finalMix}"`, { stdio: 'pipe' });
    } else {
      execSync(
        `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=stereo -t ${movieConfig.duration} -c:a aac -b:a 128k "${finalMix}"`,
        { stdio: 'pipe' }
      );
    }
  }

  return finalMix;
}

function _mixDialogueTimeline(outputFile) {
  logger.info('Building dialogue timeline...');

  // Create a silent base track
  const baseFile = 'temp/audio/silence_base.wav';
  execSync(
    `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=mono -t ${movieConfig.duration} -c:a pcm_s16le "${baseFile}"`,
    { stdio: 'pipe' }
  );

  // Overlay each voice file at its timestamp
  let currentInput = baseFile;
  let step = 0;

  for (const line of dialogueConfig) {
    const voiceFile = `temp/voices/voice_${String(line.id).padStart(3, '0')}.mp3`;
    if (!fs.existsSync(voiceFile)) continue;

    const nextOutput = `temp/audio/dial_step_${step}.wav`;
    const delayMs = Math.floor(line.start * 1000);

    try {
      execSync(
        `ffmpeg -y -i "${currentInput}" -i "${voiceFile}" -filter_complex "[1]adelay=${delayMs}|${delayMs}[d];[0][d]amix=inputs=2:duration=first:dropout_transition=0[out]" -map "[out]" -c:a pcm_s16le "${nextOutput}"`,
        { stdio: 'pipe', timeout: 60000 }
      );
      // Clean up previous step
      if (step > 0 && fs.existsSync(currentInput) && currentInput.includes('dial_step_')) {
        fs.removeSync(currentInput);
      }
      currentInput = nextOutput;
      step++;
    } catch (err) {
      logger.warn(`Failed to overlay voice ${line.id}: ${err.message}`);
    }
  }

  if (currentInput !== baseFile) {
    fs.copyFileSync(currentInput, outputFile);
  } else {
    fs.copyFileSync(baseFile, outputFile);
  }

  logger.info('Dialogue timeline built.');
}

function _mixMusicTimeline(outputFile) {
  logger.info('Building music timeline...');

  const baseFile = 'temp/audio/music_silence.wav';
  execSync(
    `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=mono -t ${movieConfig.duration} -c:a pcm_s16le "${baseFile}"`,
    { stdio: 'pipe' }
  );

  const musicFiles = [
    { file: 'temp/music/adventure_intro.wav', start: 0 },
    { file: 'temp/music/crazy_ship.wav', start: 35 },
    { file: 'temp/music/monster_theme.wav', start: 70 },
    { file: 'temp/music/island_paradise.wav', start: 110 },
    { file: 'temp/music/temple_tension.wav', start: 150 },
    { file: 'temp/music/treasure_reveal.wav', start: 190 },
    { file: 'temp/music/chaos_escape.wav', start: 235 },
    { file: 'temp/music/sunset_ending.wav', start: 275 },
  ];

  let currentInput = baseFile;
  let step = 0;

  for (const m of musicFiles) {
    if (!fs.existsSync(m.file)) continue;
    const nextOutput = `temp/audio/music_step_${step}.wav`;
    const delayMs = m.start * 1000;

    try {
      execSync(
        `ffmpeg -y -i "${currentInput}" -i "${m.file}" -filter_complex "[1]adelay=${delayMs}|${delayMs}[d];[0][d]amix=inputs=2:duration=first:dropout_transition=0[out]" -map "[out]" -c:a pcm_s16le "${nextOutput}"`,
        { stdio: 'pipe', timeout: 60000 }
      );
      if (step > 0 && currentInput.includes('music_step_')) fs.removeSync(currentInput);
      currentInput = nextOutput;
      step++;
    } catch (err) {
      logger.warn(`Music overlay failed: ${err.message}`);
    }
  }

  if (currentInput !== baseFile) {
    fs.copyFileSync(currentInput, outputFile);
  } else {
    fs.copyFileSync(baseFile, outputFile);
  }
  logger.info('Music timeline built.');
}

function _mixSfxTimeline(outputFile) {
  logger.info('Building SFX timeline...');

  const baseFile = 'temp/audio/sfx_silence.wav';
  execSync(
    `ffmpeg -y -f lavfi -i anullsrc=r=44100:cl=mono -t ${movieConfig.duration} -c:a pcm_s16le "${baseFile}"`,
    { stdio: 'pipe' }
  );

  // Place sound effects at relevant times
  const placements = [
    { file: 'temp/sfx/ocean_waves.wav', start: 0 },
    { file: 'temp/sfx/ship_creak.wav', start: 0 },
    { file: 'temp/sfx/splash.wav', start: 36 },
    { file: 'temp/sfx/comedy_impact.wav', start: 55 },
    { file: 'temp/sfx/explosion.wav', start: 60 },
    { file: 'temp/sfx/monster_roar.wav', start: 77 },
    { file: 'temp/sfx/sneeze.wav', start: 88 },
    { file: 'temp/sfx/parrot_squawk.wav', start: 101 },
    { file: 'temp/sfx/footsteps.wav', start: 132 },
    { file: 'temp/sfx/boulder_roll.wav', start: 169 },
    { file: 'temp/sfx/treasure_glow.wav', start: 191 },
    { file: 'temp/sfx/magic_sparkle.wav', start: 210 },
    { file: 'temp/sfx/temple_rumble.wav', start: 242 },
    { file: 'temp/sfx/monster_roar.wav', start: 260 },
  ];

  let currentInput = baseFile;
  let step = 0;

  for (const s of placements) {
    if (!fs.existsSync(s.file)) continue;
    const nextOutput = `temp/audio/sfx_step_${step}.wav`;
    const delayMs = s.start * 1000;

    try {
      execSync(
        `ffmpeg -y -i "${currentInput}" -i "${s.file}" -filter_complex "[1]adelay=${delayMs}|${delayMs}[d];[0][d]amix=inputs=2:duration=first:dropout_transition=0[out]" -map "[out]" -c:a pcm_s16le "${nextOutput}"`,
        { stdio: 'pipe', timeout: 60000 }
      );
      if (step > 0 && currentInput.includes('sfx_step_')) fs.removeSync(currentInput);
      currentInput = nextOutput;
      step++;
    } catch (err) {
      logger.warn(`SFX overlay failed: ${err.message}`);
    }
  }

  if (currentInput !== baseFile) {
    fs.copyFileSync(currentInput, outputFile);
  } else {
    fs.copyFileSync(baseFile, outputFile);
  }
  logger.info('SFX timeline built.');
}

module.exports = { mixAllAudio };
