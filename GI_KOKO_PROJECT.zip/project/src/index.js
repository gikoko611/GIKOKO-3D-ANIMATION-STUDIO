// src/index.js
// Master orchestrator — runs the full movie production pipeline
require('dotenv').config();
const fs = require('fs-extra');
const path = require('path');
const { logger, progress } = require('./utils/logger');
const movieConfig = require('../config/movie.config');
const { generateAllVoices } = require('./audio/tts');
const { generateMusic } = require('./audio/music');
const { generateSoundEffects } = require('./audio/sound-effects');
const { mixAllAudio } = require('./audio/mixer');
const { generateSubtitles } = require('./subtitles/subtitle-generator');
const FrameRenderer = require('./renderer/frame-renderer');
const SceneManager = require('./engine/scene-manager');
const { encodeVideo, burnSubtitles } = require('./renderer/video-encoder');
const { validateOutput } = require('./utils/validation');

async function main() {
  const startTime = Date.now();
  logger.info('═══════════════════════════════════════════════');
  logger.info('  G.I KO KO PIRATE ADVENTURE — THE CURSED GOLDEN BANANA');
  logger.info('  POWERED BY I KO KO');
  logger.info('═══════════════════════════════════════════════');

  try {
    // Setup directories
    progress(0, 'Initializing...');
    fs.ensureDirSync('output');
    fs.ensureDirSync('temp');
    fs.ensureDirSync('temp/frames');
    fs.ensureDirSync('temp/voices');
    fs.ensureDirSync('temp/music');
    fs.ensureDirSync('temp/sfx');
    fs.ensureDirSync('temp/audio');

    // Step 1: Generate English voices
    progress(5, 'Installing dependencies done. Preparing assets...');
    progress(20, 'Generating English dialogue voices...');
    await generateAllVoices();

    // Step 2: Generate Myanmar subtitles
    progress(30, 'Generating Myanmar subtitles...');
    const srtPath = generateSubtitles();

    // Step 3: Generate music & SFX
    progress(32, 'Generating background music...');
    generateMusic();
    progress(34, 'Generating sound effects...');
    generateSoundEffects();

    // Step 4: Render all 3D frames
    progress(35, 'Initializing 3D renderer...');
    const sceneManager = new SceneManager(movieConfig.width, movieConfig.height);
    sceneManager.init();

    const frameRenderer = new FrameRenderer();
    frameRenderer.init();
    frameRenderer.renderAllFrames(sceneManager);
    frameRenderer.dispose();

    // Step 5: Mix all audio
    progress(85, 'Mixing audio tracks...');
    const finalAudio = mixAllAudio();

    // Step 6: Encode video
    progress(90, 'Encoding final MP4...');
    const rawVideo = path.join('output', 'raw_video.mp4');
    encodeVideo('temp/frames', finalAudio, rawVideo);

    // Step 7: Burn subtitles
    progress(92, 'Burning Myanmar subtitles...');
    const finalVideo = path.join('output', movieConfig.output.video);
    burnSubtitles(rawVideo, srtPath, finalVideo);

    // Step 8: Validate
    progress(95, 'Validating output...');
    const result = validateOutput(finalVideo);

    // Cleanup raw video
    if (fs.existsSync(rawVideo) && rawVideo !== finalVideo) {
      fs.removeSync(rawVideo);
    }

    const elapsed = ((Date.now() - startTime) / 1000 / 60).toFixed(1);
    progress(100, `🎬 RENDERING COMPLETE! (${elapsed} minutes)`);
    logger.info('═══════════════════════════════════════════════');
    logger.info(`  Output: ${finalVideo}`);
    logger.info(`  Size: ${(result.fileSize / 1024 / 1024).toFixed(2)} MB`);
    logger.info(`  Duration: ${result.duration.toFixed(1)}s`);
    logger.info(`  Resolution: ${result.width}x${result.height}`);
    logger.info(`  Codec: ${result.videoCodec}/${result.audioCodec}`);
    logger.info('  G.I KO KO STUDIO — POWERED BY I KO KO');
    logger.info('═══════════════════════════════════════════════');

  } catch (err) {
    logger.error(`PIPELINE FAILED: ${err.message}`);
    logger.error(err.stack);
    process.exit(1);
  }
}

main();
