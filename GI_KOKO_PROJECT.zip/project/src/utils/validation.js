// src/utils/validation.js
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const { logger } = require('./logger');
const movieConfig = require('../../config/movie.config');

function validateOutput(filePath) {
  logger.info('Validating output video...');
  if (!fs.existsSync(filePath)) {
    throw new Error(`Output file not found: ${filePath}`);
  }

  const stat = fs.statSync(filePath);
  if (stat.size < 100000) {
    throw new Error(`Output file too small: ${stat.size} bytes`);
  }

  // ffprobe check
  const probe = execSync(
    `ffprobe -v quiet -print_format json -show_format -show_streams "${filePath}"`,
    { encoding: 'utf-8' }
  );
  const info = JSON.parse(probe);

  const videoStream = info.streams.find(s => s.codec_type === 'video');
  const audioStream = info.streams.find(s => s.codec_type === 'audio');

  if (!videoStream) throw new Error('No video stream found');
  if (!audioStream) throw new Error('No audio stream found');

  const duration = parseFloat(info.format.duration);
  if (Math.abs(duration - movieConfig.duration) > 2) {
    throw new Error(`Duration mismatch: expected ${movieConfig.duration}s, got ${duration.toFixed(1)}s`);
  }

  const w = parseInt(videoStream.width);
  const h = parseInt(videoStream.height);
  if (w !== movieConfig.width || h !== movieConfig.height) {
    throw new Error(`Resolution mismatch: expected ${movieConfig.width}x${movieConfig.height}, got ${w}x${h}`);
  }

  logger.info(`✅ Video validated: ${duration.toFixed(1)}s, ${w}x${h}, ${videoStream.codec_name}/${audioStream.codec_name}`);
  return { duration, width: w, height: h, videoCodec: videoStream.codec_name, audioCodec: audioStream.codec_name, fileSize: stat.size };
}

module.exports = { validateOutput };
