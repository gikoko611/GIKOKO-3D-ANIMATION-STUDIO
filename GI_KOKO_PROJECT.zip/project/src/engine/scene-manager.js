// src/engine/scene-manager.js
// Manages 3D scene composition per movie scene
const THREE = require('three');
const { createCharacters } = require('../characters/all-characters');
const { createEnvironments } = require('../environments/all-environments');
const CameraManager = require('./camera-manager');
const LightingManager = require('./lighting');
const AnimationManager = require('./animation-manager');
const scenesConfig = require('../../config/scenes.config');
const { logger } = require('../utils/logger');

class SceneManager {
  constructor(width, height) {
    this.width = width;
    this.height = height;
    this.scenes = {};
    this.camera = new CameraManager(width, height);
    this.lighting = new LightingManager();
    this.animation = new AnimationManager();
    this.characters = createCharacters();
    this.environments = createEnvironments();
    this.initialized = false;
  }

  init() {
    logger.info('Initializing scene manager...');
    this._buildAllScenes();
    this.initialized = true;
  }

  _buildAllScenes() {
    for (const sc of scenesConfig) {
      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x87CEEB); // sky blue

      // Add lighting
      this.lighting.addTo(scene, sc.id);

      // Add environment
      const env = this._getEnvironment(sc.id);
      if (env) scene.add(env);

      // Add characters
      const chars = this._getCharactersForScene(sc.id);
      chars.forEach(c => scene.add(c));

      this.scenes[sc.id] = scene;
    }
  }

  _getEnvironment(sceneId) {
    switch (sceneId) {
      case 1: case 2:
        return this.environments.ocean.clone ? this.environments.ocean.clone() : this.environments.ocean;
      case 3:
        return this.environments.oceanStorm || this.environments.ocean;
      case 4:
        return this.environments.island;
      case 5: case 6:
        return this.environments.temple;
      case 7:
        return this.environments.templeCollapse || this.environments.temple;
      case 8:
        return this.environments.sunset || this.environments.ocean;
      default:
        return this.environments.ocean;
    }
  }

  _getCharactersForScene(sceneId) {
    const chars = [];
    switch (sceneId) {
      case 1: case 2:
        chars.push(this.characters.captain, this.characters.bobby, this.characters.parrot);
        break;
      case 3:
        chars.push(this.characters.captain, this.characters.bobby, this.characters.parrot, this.characters.monster);
        break;
      case 4:
        chars.push(this.characters.captain, this.characters.bobby, this.characters.parrot);
        break;
      case 5:
        chars.push(this.characters.captain, this.characters.bobby, this.characters.parrot);
        break;
      case 6:
        chars.push(this.characters.captain, this.characters.bobby, this.characters.parrot, this.characters.guardian);
        break;
      case 7:
        chars.push(this.characters.captain, this.characters.bobby, this.characters.parrot, this.characters.monster);
        break;
      case 8:
        chars.push(this.characters.captain, this.characters.bobby, this.characters.parrot, this.characters.monster);
        break;
    }
    // Deep-clone characters for each scene so positions don't collide
    return chars.map(c => {
      const clone = c.clone();
      clone.userData = { ...c.userData };
      return clone;
    });
  }

  getScene(sceneId, time, frame) {
    const scene = this.scenes[sceneId];
    if (!scene) {
      logger.warn(`Scene ${sceneId} not found, using scene 1`);
      return this.getScene(1, time, frame);
    }

    const sceneConfig = scenesConfig.find(s => s.id === sceneId);
    const localTime = time - sceneConfig.start;
    const sceneDuration = sceneConfig.end - sceneConfig.start;
    const t = localTime / sceneDuration; // 0-1 normalized progress

    // Update animations
    this.animation.update(scene, sceneId, localTime, t);

    // Update camera
    const camera = this.camera.update(sceneId, localTime, t);

    return { scene, camera };
  }
}

module.exports = SceneManager;
