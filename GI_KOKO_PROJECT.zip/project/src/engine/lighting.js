// src/engine/lighting.js
// Cinematic lighting system
const THREE = require('three');

class LightingManager {
  addTo(scene, sceneId) {
    // Ambient light (always present)
    const ambient = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambient);

    // Hemisphere light for natural sky-ground gradient
    const hemi = new THREE.HemisphereLight(0x87CEEB, 0x443322, 0.3);
    scene.add(hemi);

    switch (sceneId) {
      case 1: case 2:
        this._outdoorSunlight(scene);
        break;
      case 3:
        this._stormLighting(scene);
        break;
      case 4:
        this._tropicalSunlight(scene);
        break;
      case 5: case 6:
        this._templeLighting(scene);
        break;
      case 7:
        this._chaosLighting(scene);
        break;
      case 8:
        this._sunsetLighting(scene);
        break;
    }
  }

  _outdoorSunlight(scene) {
    const sun = new THREE.DirectionalLight(0xFFD700, 1.0);
    sun.position.set(5, 10, 5);
    scene.add(sun);
  }

  _stormLighting(scene) {
    const sun = new THREE.DirectionalLight(0x8899AA, 0.6);
    sun.position.set(3, 8, 3);
    scene.add(sun);
    const fill = new THREE.PointLight(0x4466AA, 0.4, 20);
    fill.position.set(0, 5, 0);
    scene.add(fill);
  }

  _tropicalSunlight(scene) {
    const sun = new THREE.DirectionalLight(0xFFDD44, 1.2);
    sun.position.set(5, 12, 5);
    scene.add(sun);
    const fill = new THREE.PointLight(0x44FF44, 0.2, 15);
    fill.position.set(-3, 2, 3);
    scene.add(fill);
  }

  _templeLighting(scene) {
    scene.background = new THREE.Color(0x1a1a2e);
    const torch1 = new THREE.PointLight(0xFF6600, 0.8, 10);
    torch1.position.set(-3, 3, 2);
    scene.add(torch1);
    const torch2 = new THREE.PointLight(0xFF6600, 0.8, 10);
    torch2.position.set(3, 3, -2);
    scene.add(torch2);
    const treasure = new THREE.PointLight(0xFFD700, 0.6, 8);
    treasure.position.set(0, 2, -3);
    scene.add(treasure);
  }

  _chaosLighting(scene) {
    scene.background = new THREE.Color(0x2a1a0a);
    const red = new THREE.PointLight(0xFF3300, 1.0, 15);
    red.position.set(0, 5, 0);
    scene.add(red);
    const flicker = new THREE.PointLight(0xFF6600, 0.5, 10);
    flicker.position.set(-2, 3, 2);
    scene.add(flicker);
  }

  _sunsetLighting(scene) {
    scene.background = new THREE.Color(0xFF7744);
    const sun = new THREE.DirectionalLight(0xFF8833, 1.0);
    sun.position.set(-5, 3, 5);
    scene.add(sun);
    const ambient = new THREE.AmbientLight(0xFF6633, 0.3);
    scene.add(ambient);
  }
}

module.exports = LightingManager;
