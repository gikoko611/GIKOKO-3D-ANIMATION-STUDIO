// src/engine/camera-manager.js
// Professional cinematic camera system for 9:16 vertical format
const THREE = require('three');

class CameraManager {
  constructor(width, height) {
    this.camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    this.camera.position.set(0, 2, 8);
    this.camera.lookAt(0, 1, 0);
  }

  update(sceneId, localTime, t) {
    switch (sceneId) {
      case 1: this._scene1Camera(localTime, t); break;
      case 2: this._scene2Camera(localTime, t); break;
      case 3: this._scene3Camera(localTime, t); break;
      case 4: this._scene4Camera(localTime, t); break;
      case 5: this._scene5Camera(localTime, t); break;
      case 6: this._scene6Camera(localTime, t); break;
      case 7: this._scene7Camera(localTime, t); break;
      case 8: this._scene8Camera(localTime, t); break;
    }
    return this.camera;
  }

  _scene1Camera(lt, t) {
    // Establishing wide shot -> close-up on map -> reaction shots
    if (t < 0.3) {
      // Wide establishing shot of ship
      this.camera.position.set(
        Math.sin(lt * 0.1) * 2,
        3 + Math.sin(lt * 0.2) * 0.3,
        10 - t * 5
      );
      this.camera.lookAt(0, 1, 0);
    } else if (t < 0.6) {
      // Close-up on captain
      this.camera.position.set(0.5, 2.2, 3);
      this.camera.lookAt(0, 2, 0);
    } else {
      // Pull back group shot
      this.camera.position.set(
        Math.sin(lt * 0.3) * 1.5,
        2.5,
        7
      );
      this.camera.lookAt(0, 1.5, 0);
    }
  }

  _scene2Camera(lt, t) {
    // Dynamic ship chaos camera
    const shake = t > 0.5 ? Math.sin(lt * 10) * 0.1 : 0;
    this.camera.position.set(
      Math.sin(lt * 0.5) * 3 + shake,
      2.5 + Math.cos(lt * 0.3) * 0.5 + shake,
      6 + Math.sin(lt * 0.2) * 2
    );
    this.camera.lookAt(shake, 1.5, 0);
  }

  _scene3Camera(lt, t) {
    // Monster reveal - low angle hero shot
    if (t < 0.3) {
      // Low angle looking up at approaching monster
      this.camera.position.set(0, 0.5, 8);
      this.camera.lookAt(0, 5, -5);
    } else if (t < 0.6) {
      // Orbit around monster
      const angle = lt * 0.3;
      this.camera.position.set(Math.sin(angle) * 8, 3, Math.cos(angle) * 8);
      this.camera.lookAt(0, 2, 0);
    } else {
      // Captain flying through air
      this.camera.position.set(
        Math.sin(lt) * 3,
        4 + Math.sin(lt * 2) * 2,
        5
      );
      this.camera.lookAt(0, 3, 0);
    }
  }

  _scene4Camera(lt, t) {
    // Aerial establishing -> tracking through jungle
    if (t < 0.25) {
      // High aerial shot
      this.camera.position.set(0, 15, 15);
      this.camera.lookAt(0, 0, 0);
    } else if (t < 0.5) {
      // Descending to island
      const descend = (t - 0.25) / 0.25;
      this.camera.position.set(
        Math.sin(lt * 0.2) * 5,
        15 - descend * 12,
        15 - descend * 8
      );
      this.camera.lookAt(0, 1, 0);
    } else {
      // Tracking shot through jungle
      this.camera.position.set(
        -3 + t * 6,
        2,
        5
      );
      this.camera.lookAt(t * 2, 1.5, 0);
    }
  }

  _scene5Camera(lt, t) {
    // Fast-paced temple action camera
    const shake = Math.sin(lt * 15) * 0.05 * t;
    this.camera.position.set(
      Math.sin(lt * 0.8) * 4 + shake,
      2 + Math.abs(Math.sin(lt * 2)) * 1.5,
      5 + Math.sin(lt * 0.3) * 3
    );
    this.camera.lookAt(shake, 1.5, 0);
  }

  _scene6Camera(lt, t) {
    // Dramatic treasure reveal
    if (t < 0.3) {
      // Slow push-in on golden banana
      this.camera.position.set(0, 2, 8 - t * 10);
      this.camera.lookAt(0, 2, -2);
    } else if (t < 0.6) {
      // Guardian reveal - low angle
      this.camera.position.set(2, 0.5, 5);
      this.camera.lookAt(-1, 3, 0);
    } else {
      // Confrontation two-shot
      const angle = lt * 0.2;
      this.camera.position.set(Math.sin(angle) * 5, 2, Math.cos(angle) * 5);
      this.camera.lookAt(0, 2, 0);
    }
  }

  _scene7Camera(lt, t) {
    // Chaos escape — fast cuts, shaking
    const shake = Math.sin(lt * 20) * 0.15;
    this.camera.position.set(
      Math.sin(lt * 1.5) * 5 + shake,
      2.5 + shake,
      4 + Math.sin(lt * 0.5) * 4
    );
    this.camera.lookAt(shake, 1.5 + shake, 0);
  }

  _scene8Camera(lt, t) {
    // Sunset ending — calm orbit
    if (t < 0.6) {
      const angle = lt * 0.15;
      this.camera.position.set(Math.sin(angle) * 7, 2.5, Math.cos(angle) * 7);
      this.camera.lookAt(0, 1.5, 0);
    } else {
      // Zoom out for ending
      this.camera.position.set(0, 3 + t * 5, 10 + t * 5);
      this.camera.lookAt(0, 1, 0);
    }
  }
}

module.exports = CameraManager;
