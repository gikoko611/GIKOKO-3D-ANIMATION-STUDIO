// src/engine/animation-manager.js
// Handles character animation: walking, talking, expressions, scene-specific actions
const THREE = require('three');

class AnimationManager {
  update(scene, sceneId, localTime, t) {
    scene.traverse((child) => {
      if (!child.userData || !child.userData.type) return;

      const type = child.userData.type;
      switch (type) {
        case 'captain':
          this._animateCaptain(child, sceneId, localTime, t);
          break;
        case 'bobby':
          this._animateBobby(child, sceneId, localTime, t);
          break;
        case 'parrot':
          this._animateParrot(child, sceneId, localTime, t);
          break;
        case 'monster':
          this._animateMonster(child, sceneId, localTime, t);
          break;
        case 'guardian':
          this._animateGuardian(child, sceneId, localTime, t);
          break;
        case 'ocean':
          this._animateOcean(child, localTime);
          break;
        case 'ship':
          this._animateShip(child, localTime);
          break;
      }
    });
  }

  _animateCaptain(group, sceneId, lt, t) {
    // Idle bobbing
    group.position.y = (group.userData.baseY || 0) + Math.sin(lt * 2) * 0.05;

    // Head rotation (looking around)
    const head = group.getObjectByName('head');
    if (head) {
      head.rotation.y = Math.sin(lt * 1.5) * 0.2;
      head.rotation.x = Math.sin(lt * 0.8) * 0.05;
    }

    // Arm swing
    const leftArm = group.getObjectByName('leftArm');
    const rightArm = group.getObjectByName('rightArm');
    if (leftArm) leftArm.rotation.x = Math.sin(lt * 3) * 0.3;
    if (rightArm) rightArm.rotation.x = Math.sin(lt * 3 + Math.PI) * 0.3;

    // Leg walk cycle
    const leftLeg = group.getObjectByName('leftLeg');
    const rightLeg = group.getObjectByName('rightLeg');
    if (leftLeg) leftLeg.rotation.x = Math.sin(lt * 3) * 0.25;
    if (rightLeg) rightLeg.rotation.x = Math.sin(lt * 3 + Math.PI) * 0.25;

    // Scene-specific
    if (sceneId === 3 && t > 0.6) {
      // Flying through air
      group.position.y = 3 + Math.sin(lt * 2) * 2;
      group.rotation.z = Math.sin(lt * 3) * 0.5;
    }
    if (sceneId === 7) {
      // Running
      group.position.x = -3 + t * 6;
      if (leftLeg) leftLeg.rotation.x = Math.sin(lt * 8) * 0.5;
      if (rightLeg) rightLeg.rotation.x = Math.sin(lt * 8 + Math.PI) * 0.5;
    }
  }

  _animateBobby(group, sceneId, lt, t) {
    group.position.y = (group.userData.baseY || 0) + Math.sin(lt * 2.5) * 0.05;

    const head = group.getObjectByName('head');
    if (head) {
      head.rotation.y = Math.sin(lt * 2) * 0.3;
      head.rotation.z = Math.sin(lt * 1.5) * 0.1;
    }

    const leftArm = group.getObjectByName('leftArm');
    const rightArm = group.getObjectByName('rightArm');
    if (leftArm) leftArm.rotation.x = Math.sin(lt * 3.5) * 0.4;
    if (rightArm) rightArm.rotation.x = Math.sin(lt * 3.5 + Math.PI) * 0.4;

    const leftLeg = group.getObjectByName('leftLeg');
    const rightLeg = group.getObjectByName('rightLeg');
    if (leftLeg) leftLeg.rotation.x = Math.sin(lt * 3.5) * 0.3;
    if (rightLeg) rightLeg.rotation.x = Math.sin(lt * 3.5 + Math.PI) * 0.3;

    if (sceneId === 7) {
      group.position.x = -2 + t * 5;
    }
    if (sceneId === 8 && t > 0.5) {
      // Eating animation
      if (head) head.rotation.x = Math.sin(lt * 6) * 0.15;
    }
  }

  _animateParrot(group, sceneId, lt, t) {
    // Flying bob
    group.position.y = (group.userData.baseY || 3) + Math.sin(lt * 3) * 0.3;
    group.position.x = (group.userData.baseX || 0) + Math.sin(lt * 1.2) * 1;

    // Wing flap
    const leftWing = group.getObjectByName('leftWing');
    const rightWing = group.getObjectByName('rightWing');
    if (leftWing) leftWing.rotation.z = Math.sin(lt * 8) * 0.5;
    if (rightWing) rightWing.rotation.z = -Math.sin(lt * 8) * 0.5;

    // Head tilt
    const head = group.getObjectByName('head');
    if (head) head.rotation.z = Math.sin(lt * 2) * 0.2;
  }

  _animateMonster(group, sceneId, lt, t) {
    // Large breathing motion
    const scale = 1 + Math.sin(lt * 1.5) * 0.03;
    group.scale.set(scale, scale, scale);
    group.position.y = (group.userData.baseY || 0) + Math.sin(lt * 0.8) * 0.3;

    if (sceneId === 3 && t > 0.4 && t < 0.55) {
      // Sneeze buildup and release
      const sneeze = (t - 0.4) / 0.15;
      group.scale.set(1 + sneeze * 0.2, 1 - sneeze * 0.1, 1 + sneeze * 0.2);
    }
  }

  _animateGuardian(group, sceneId, lt, t) {
    // Mysterious floating
    group.position.y = (group.userData.baseY || 0) + Math.sin(lt * 1) * 0.2;
    group.rotation.y = lt * 0.3;

    // Glow pulse (scale pulse)
    const pulse = 1 + Math.sin(lt * 2) * 0.05;
    group.scale.set(pulse, pulse, pulse);
  }

  _animateOcean(mesh, lt) {
    if (mesh.geometry && mesh.geometry.attributes && mesh.geometry.attributes.position) {
      const pos = mesh.geometry.attributes.position;
      const basePos = mesh.userData.basePositions;
      if (!basePos) return;

      for (let i = 0; i < pos.count; i++) {
        const bx = basePos[i * 3];
        const bz = basePos[i * 3 + 2];
        pos.setY(i, Math.sin(bx * 0.5 + lt * 1.5) * 0.3 + Math.cos(bz * 0.3 + lt) * 0.2);
      }
      pos.needsUpdate = true;
    }
  }

  _animateShip(group, lt) {
    // Ship rocking on ocean
    group.rotation.z = Math.sin(lt * 0.8) * 0.05;
    group.rotation.x = Math.sin(lt * 0.6) * 0.03;
    group.position.y = (group.userData.baseY || 0.5) + Math.sin(lt * 1.2) * 0.15;
  }
}

module.exports = AnimationManager;
