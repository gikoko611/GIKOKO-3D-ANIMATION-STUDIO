// src/environments/all-environments.js
// Procedural 3D environments
const THREE = require('three');

function createOceanEnvironment() {
  const group = new THREE.Group();

  // Ocean plane with wave-able vertices
  const oceanGeo = new THREE.PlaneGeometry(60, 60, 40, 40);
  oceanGeo.rotateX(-Math.PI / 2);
  const basePositions = new Float32Array(oceanGeo.attributes.position.array);

  const ocean = new THREE.Mesh(oceanGeo,
    new THREE.MeshStandardMaterial({
      color: 0x1E90FF,
      transparent: true,
      opacity: 0.85,
      roughness: 0.3,
      metalness: 0.1,
      side: THREE.DoubleSide,
    })
  );
  ocean.userData = { type: 'ocean', basePositions: basePositions };
  ocean.position.y = -0.5;
  group.add(ocean);

  // Pirate ship
  const ship = createShip();
  ship.position.set(0, 0.5, 0);
  group.add(ship);

  // Sun (distant glowing sphere)
  const sun = new THREE.Mesh(
    new THREE.SphereGeometry(2, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0xFFDD44, emissive: 0xFFDD44, emissiveIntensity: 1.0 })
  );
  sun.position.set(15, 20, -30);
  group.add(sun);

  // Clouds
  for (let i = 0; i < 6; i++) {
    const cloud = createCloud();
    cloud.position.set(
      (Math.random() - 0.5) * 40,
      12 + Math.random() * 5,
      -10 - Math.random() * 20
    );
    cloud.scale.setScalar(0.8 + Math.random() * 1.2);
    group.add(cloud);
  }

  return group;
}

function createShip() {
  const ship = new THREE.Group();
  ship.userData = { type: 'ship', baseY: 0.5 };

  // Hull
  const hull = new THREE.Mesh(
    new THREE.BoxGeometry(3, 0.8, 1.2),
    new THREE.MeshStandardMaterial({ color: 0x8B4513 })
  );
  hull.position.y = 0;
  ship.add(hull);

  // Deck
  const deck = new THREE.Mesh(
    new THREE.BoxGeometry(2.8, 0.1, 1.1),
    new THREE.MeshStandardMaterial({ color: 0xA0522D })
  );
  deck.position.y = 0.4;
  ship.add(deck);

  // Mast
  const mast = new THREE.Mesh(
    new THREE.CylinderGeometry(0.05, 0.06, 4, 8),
    new THREE.MeshStandardMaterial({ color: 0x654321 })
  );
  mast.position.y = 2.4;
  ship.add(mast);

  // Sail
  const sail = new THREE.Mesh(
    new THREE.PlaneGeometry(1.5, 2),
    new THREE.MeshStandardMaterial({ color: 0xFFF8DC, side: THREE.DoubleSide })
  );
  sail.position.set(0, 2.5, 0.1);
  ship.add(sail);

  // Skull flag
  const flag = new THREE.Mesh(
    new THREE.PlaneGeometry(0.4, 0.3),
    new THREE.MeshStandardMaterial({ color: 0x111111, side: THREE.DoubleSide })
  );
  flag.position.set(0, 4.2, 0.1);
  ship.add(flag);

  // Railing
  for (let x = -1.2; x <= 1.2; x += 0.4) {
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.02, 0.02, 0.5, 6),
      new THREE.MeshStandardMaterial({ color: 0x654321 })
    );
    post.position.set(x, 0.7, 0.55);
    ship.add(post);
    const post2 = post.clone();
    post2.position.z = -0.55;
    ship.add(post2);
  }

  // Wheel
  const wheel = new THREE.Mesh(
    new THREE.TorusGeometry(0.2, 0.03, 8, 12),
    new THREE.MeshStandardMaterial({ color: 0x8B4513 })
  );
  wheel.position.set(-1.2, 1.0, 0);
  wheel.rotation.y = Math.PI / 2;
  ship.add(wheel);

  return ship;
}

function createCloud() {
  const cloud = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0xFFFFFF, transparent: true, opacity: 0.8 });

  for (let i = 0; i < 5; i++) {
    const puff = new THREE.Mesh(
      new THREE.SphereGeometry(0.5 + Math.random() * 0.5, 8, 8),
      mat
    );
    puff.position.set(
      (Math.random() - 0.5) * 2,
      (Math.random() - 0.5) * 0.5,
      (Math.random() - 0.5) * 0.5
    );
    cloud.add(puff);
  }
  return cloud;
}

function createIslandEnvironment() {
  const group = new THREE.Group();

  // Ground
  const ground = new THREE.Mesh(
    new THREE.CylinderGeometry(8, 10, 0.5, 20),
    new THREE.MeshStandardMaterial({ color: 0xF4A460 }) // sandy
  );
  ground.position.y = -0.25;
  group.add(ground);

  // Grass layer
  const grass = new THREE.Mesh(
    new THREE.CylinderGeometry(6, 7, 0.1, 20),
    new THREE.MeshStandardMaterial({ color: 0x228B22 })
  );
  grass.position.y = 0.05;
  group.add(grass);

  // Palm trees
  for (let i = 0; i < 6; i++) {
    const palm = createPalmTree();
    const angle = (i / 6) * Math.PI * 2;
    palm.position.set(Math.cos(angle) * 5, 0, Math.sin(angle) * 5);
    palm.rotation.y = Math.random() * Math.PI;
    palm.scale.setScalar(0.8 + Math.random() * 0.4);
    group.add(palm);
  }

  // Waterfall
  const waterfall = new THREE.Mesh(
    new THREE.PlaneGeometry(0.5, 3),
    new THREE.MeshStandardMaterial({ color: 0x44AAFF, transparent: true, opacity: 0.7, side: THREE.DoubleSide })
  );
  waterfall.position.set(-4, 1.5, -3);
  group.add(waterfall);

  // Rock formations
  for (let i = 0; i < 4; i++) {
    const rock = new THREE.Mesh(
      new THREE.DodecahedronGeometry(0.5 + Math.random() * 0.5),
      new THREE.MeshStandardMaterial({ color: 0x888888 })
    );
    rock.position.set(
      (Math.random() - 0.5) * 10,
      0.2,
      (Math.random() - 0.5) * 10
    );
    group.add(rock);
  }

  // Beach ocean
  const beachOcean = new THREE.Mesh(
    new THREE.PlaneGeometry(40, 40),
    new THREE.MeshStandardMaterial({ color: 0x1E90FF, transparent: true, opacity: 0.7 })
  );
  beachOcean.rotation.x = -Math.PI / 2;
  beachOcean.position.y = -0.5;
  group.add(beachOcean);

  // Exotic flowers
  const flowerColors = [0xFF1493, 0xFF6347, 0xFFD700, 0x9370DB, 0xFF69B4];
  for (let i = 0; i < 15; i++) {
    const flower = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 6, 6),
      new THREE.MeshStandardMaterial({ color: flowerColors[i % flowerColors.length] })
    );
    flower.position.set(
      (Math.random() - 0.5) * 8,
      0.1,
      (Math.random() - 0.5) * 8
    );
    group.add(flower);
  }

  return group;
}

function createPalmTree() {
  const palm = new THREE.Group();

  // Trunk (curved cylinder)
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.15, 3, 8),
    new THREE.MeshStandardMaterial({ color: 0x8B6914 })
  );
  trunk.position.y = 1.5;
  trunk.rotation.z = 0.1;
  palm.add(trunk);

  // Leaves
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x228B22, side: THREE.DoubleSide });
  for (let i = 0; i < 6; i++) {
    const leaf = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 1.5), leafMat);
    leaf.position.set(0, 3, 0);
    leaf.rotation.y = (i / 6) * Math.PI * 2;
    leaf.rotation.x = -0.5;
    palm.add(leaf);
  }

  // Coconuts
  for (let i = 0; i < 3; i++) {
    const coconut = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 8, 8),
      new THREE.MeshStandardMaterial({ color: 0x654321 })
    );
    coconut.position.set(
      Math.cos(i * 2.1) * 0.15,
      2.9,
      Math.sin(i * 2.1) * 0.15
    );
    palm.add(coconut);
  }

  return palm;
}

function createTempleEnvironment() {
  const group = new THREE.Group();

  // Floor
  const floor = new THREE.Mesh(
    new THREE.BoxGeometry(12, 0.2, 12),
    new THREE.MeshStandardMaterial({ color: 0x8B7355 })
  );
  floor.position.y = -0.1;
  group.add(floor);

  // Stone walls
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x696969 });
  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 5, 12), wallMat);
  leftWall.position.set(-6, 2.5, 0);
  group.add(leftWall);

  const rightWall = new THREE.Mesh(new THREE.BoxGeometry(0.3, 5, 12), wallMat);
  rightWall.position.set(6, 2.5, 0);
  group.add(rightWall);

  const backWall = new THREE.Mesh(new THREE.BoxGeometry(12, 5, 0.3), wallMat);
  backWall.position.set(0, 2.5, -6);
  group.add(backWall);

  // Pillars
  const pillarMat = new THREE.MeshStandardMaterial({ color: 0x8B8378 });
  for (let i = 0; i < 4; i++) {
    const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.35, 5, 8), pillarMat);
    pillar.position.set(-3 + i * 2, 2.5, -2);
    group.add(pillar);
  }

  // Torch holders
  const torchMat = new THREE.MeshStandardMaterial({ color: 0xFF6600, emissive: 0xFF4400, emissiveIntensity: 0.5 });
  for (let i = 0; i < 4; i++) {
    const torch = new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8), torchMat);
    torch.position.set(
      i < 2 ? -5.5 : 5.5,
      3,
      i % 2 === 0 ? -3 : 3
    );
    group.add(torch);
  }

  // Golden banana pedestal (for scene 6)
  const pedestal = new THREE.Mesh(
    new THREE.CylinderGeometry(0.5, 0.6, 1, 12),
    new THREE.MeshStandardMaterial({ color: 0xDAA520 })
  );
  pedestal.position.set(0, 0.5, -4);
  group.add(pedestal);

  // Golden Banana
  const banana = new THREE.Group();
  const bananaBody = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.12, 0.5, 8, 12),
    new THREE.MeshStandardMaterial({ color: 0xFFD700, metalness: 0.8, roughness: 0.1, emissive: 0xFFAA00, emissiveIntensity: 0.3 })
  );
  bananaBody.rotation.z = 0.3;
  banana.add(bananaBody);
  banana.position.set(0, 1.3, -4);
  group.add(banana);

  // Ancient symbols on walls (decorative cubes)
  const symbolMat = new THREE.MeshStandardMaterial({ color: 0xFFD700, emissive: 0xFFAA00, emissiveIntensity: 0.2 });
  for (let i = 0; i < 8; i++) {
    const symbol = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.05), symbolMat);
    symbol.position.set(
      -5.8,
      1 + (i % 4) * 0.8,
      -3 + Math.floor(i / 4) * 6
    );
    group.add(symbol);
  }

  return group;
}

function createSunsetEnvironment() {
  const group = new THREE.Group();

  // Ocean
  const ocean = new THREE.Mesh(
    new THREE.PlaneGeometry(60, 60, 20, 20),
    new THREE.MeshStandardMaterial({ color: 0xFF6633, transparent: true, opacity: 0.7, metalness: 0.3 })
  );
  ocean.rotation.x = -Math.PI / 2;
  ocean.position.y = -0.5;
  group.add(ocean);

  // Setting sun
  const sun = new THREE.Mesh(
    new THREE.SphereGeometry(3, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0xFF4400, emissive: 0xFF4400, emissiveIntensity: 1.0 })
  );
  sun.position.set(0, 5, -25);
  group.add(sun);

  // Ship
  const ship = createShip();
  ship.position.set(0, 0.5, 0);
  group.add(ship);

  return group;
}

function createEnvironments() {
  return {
    ocean: createOceanEnvironment(),
    island: createIslandEnvironment(),
    temple: createTempleEnvironment(),
    sunset: createSunsetEnvironment(),
  };
}

module.exports = { createEnvironments };
