// src/characters/all-characters.js
// Procedural 3D character models built from primitives
const THREE = require('three');

function createCaptain() {
  const group = new THREE.Group();
  group.userData = { type: 'captain', baseY: 0 };

  // Body (red coat)
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(0.8, 1.2, 0.5),
    new THREE.MeshStandardMaterial({ color: 0xCC2222 })
  );
  body.position.y = 1.6;
  group.add(body);

  // Head
  const headGroup = new THREE.Group();
  headGroup.name = 'head';
  headGroup.position.y = 2.6;

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.35, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0xFFCC99 })
  );
  headGroup.add(head);

  // Eyes (big expressive)
  const eyeGeo = new THREE.SphereGeometry(0.08, 8, 8);
  const eyeMat = new THREE.MeshStandardMaterial({ color: 0xFFFFFF });
  const pupilMat = new THREE.MeshStandardMaterial({ color: 0x222222 });

  const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
  leftEye.position.set(-0.12, 0.05, 0.3);
  headGroup.add(leftEye);

  const leftPupil = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 6), pupilMat);
  leftPupil.position.set(-0.12, 0.05, 0.36);
  headGroup.add(leftPupil);

  const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
  rightEye.position.set(0.12, 0.05, 0.3);
  headGroup.add(rightEye);

  const rightPupil = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 6), pupilMat);
  rightPupil.position.set(0.12, 0.05, 0.36);
  headGroup.add(rightPupil);

  // Mouth
  const mouth = new THREE.Mesh(
    new THREE.BoxGeometry(0.15, 0.03, 0.05),
    new THREE.MeshStandardMaterial({ color: 0x993333 })
  );
  mouth.position.set(0, -0.12, 0.3);
  headGroup.add(mouth);

  // Oversized pirate hat
  const hatBrim = new THREE.Mesh(
    new THREE.CylinderGeometry(0.5, 0.55, 0.06, 16),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  hatBrim.position.y = 0.3;
  headGroup.add(hatBrim);

  const hatTop = new THREE.Mesh(
    new THREE.BoxGeometry(0.4, 0.4, 0.3),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  hatTop.position.y = 0.52;
  headGroup.add(hatTop);

  // Skull on hat
  const skull = new THREE.Mesh(
    new THREE.SphereGeometry(0.06, 6, 6),
    new THREE.MeshStandardMaterial({ color: 0xFFFFFF })
  );
  skull.position.set(0, 0.5, 0.17);
  headGroup.add(skull);

  group.add(headGroup);

  // Left arm
  const leftArm = new THREE.Group();
  leftArm.name = 'leftArm';
  leftArm.position.set(-0.55, 2.0, 0);
  const armMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.07, 0.8, 8),
    new THREE.MeshStandardMaterial({ color: 0xCC2222 })
  );
  armMesh.position.y = -0.4;
  leftArm.add(armMesh);
  // Hand
  const hand = new THREE.Mesh(
    new THREE.SphereGeometry(0.07, 8, 8),
    new THREE.MeshStandardMaterial({ color: 0xFFCC99 })
  );
  hand.position.y = -0.8;
  leftArm.add(hand);
  group.add(leftArm);

  // Right arm with golden hook
  const rightArm = new THREE.Group();
  rightArm.name = 'rightArm';
  rightArm.position.set(0.55, 2.0, 0);
  const rArmMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.08, 0.07, 0.8, 8),
    new THREE.MeshStandardMaterial({ color: 0xCC2222 })
  );
  rArmMesh.position.y = -0.4;
  rightArm.add(rArmMesh);
  // Golden hook
  const hook = new THREE.Mesh(
    new THREE.TorusGeometry(0.07, 0.02, 8, 12, Math.PI),
    new THREE.MeshStandardMaterial({ color: 0xFFD700, metalness: 0.8, roughness: 0.2 })
  );
  hook.position.set(0, -0.85, 0);
  hook.rotation.z = Math.PI / 2;
  rightArm.add(hook);
  group.add(rightArm);

  // Legs
  const legMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
  const leftLeg = new THREE.Group();
  leftLeg.name = 'leftLeg';
  leftLeg.position.set(-0.2, 0.9, 0);
  const lLegMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.08, 0.8, 8), legMat);
  lLegMesh.position.y = -0.4;
  leftLeg.add(lLegMesh);
  // Boot
  const bootMat = new THREE.MeshStandardMaterial({ color: 0x442200 });
  const lBoot = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.15, 0.25), bootMat);
  lBoot.position.set(0, -0.85, 0.05);
  leftLeg.add(lBoot);
  group.add(leftLeg);

  const rightLeg = new THREE.Group();
  rightLeg.name = 'rightLeg';
  rightLeg.position.set(0.2, 0.9, 0);
  const rLegMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.08, 0.8, 8), legMat);
  rLegMesh.position.y = -0.4;
  rightLeg.add(rLegMesh);
  const rBoot = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.15, 0.25), bootMat);
  rBoot.position.set(0, -0.85, 0.05);
  rightLeg.add(rBoot);
  group.add(rightLeg);

  // Belt with buckle
  const belt = new THREE.Mesh(
    new THREE.BoxGeometry(0.85, 0.1, 0.55),
    new THREE.MeshStandardMaterial({ color: 0x442200 })
  );
  belt.position.y = 1.1;
  group.add(belt);
  const buckle = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.12, 0.05),
    new THREE.MeshStandardMaterial({ color: 0xFFD700, metalness: 0.9 })
  );
  buckle.position.set(0, 1.1, 0.3);
  group.add(buckle);

  group.position.set(-1, 0, 0);
  return group;
}

function createBobby() {
  const group = new THREE.Group();
  group.userData = { type: 'bobby', baseY: 0 };

  // Body (smaller, brown vest)
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(0.6, 0.9, 0.4),
    new THREE.MeshStandardMaterial({ color: 0x886644 })
  );
  body.position.y = 1.2;
  group.add(body);

  // Head (round, expressive)
  const headGroup = new THREE.Group();
  headGroup.name = 'head';
  headGroup.position.y = 2.0;

  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0xFFCC99 })
  );
  headGroup.add(head);

  // Green bandana
  const bandana = new THREE.Mesh(
    new THREE.CylinderGeometry(0.32, 0.3, 0.12, 16),
    new THREE.MeshStandardMaterial({ color: 0x228B22 })
  );
  bandana.position.y = 0.15;
  headGroup.add(bandana);

  // Big eyes
  const eyeMat = new THREE.MeshStandardMaterial({ color: 0xFFFFFF });
  const lEye = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), eyeMat);
  lEye.position.set(-0.1, 0.05, 0.25);
  headGroup.add(lEye);
  const rEye = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), eyeMat);
  rEye.position.set(0.1, 0.05, 0.25);
  headGroup.add(rEye);

  const pupilMat = new THREE.MeshStandardMaterial({ color: 0x222222 });
  const lP = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 6), pupilMat);
  lP.position.set(-0.1, 0.05, 0.3);
  headGroup.add(lP);
  const rP = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 6), pupilMat);
  rP.position.set(0.1, 0.05, 0.3);
  headGroup.add(rP);

  // Big goofy smile
  const smile = new THREE.Mesh(
    new THREE.TorusGeometry(0.08, 0.02, 6, 12, Math.PI),
    new THREE.MeshStandardMaterial({ color: 0x993333 })
  );
  smile.position.set(0, -0.1, 0.25);
  smile.rotation.x = Math.PI;
  headGroup.add(smile);

  group.add(headGroup);

  // Arms
  const armMat = new THREE.MeshStandardMaterial({ color: 0xFFCC99 });
  const leftArm = new THREE.Group();
  leftArm.name = 'leftArm';
  leftArm.position.set(-0.42, 1.5, 0);
  const lArmMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.05, 0.6, 8), armMat);
  lArmMesh.position.y = -0.3;
  leftArm.add(lArmMesh);
  group.add(leftArm);

  const rightArm = new THREE.Group();
  rightArm.name = 'rightArm';
  rightArm.position.set(0.42, 1.5, 0);
  const rArmMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.05, 0.6, 8), armMat);
  rArmMesh.position.y = -0.3;
  rightArm.add(rArmMesh);
  group.add(rightArm);

  // Legs
  const legMat = new THREE.MeshStandardMaterial({ color: 0x556B2F });
  const leftLeg = new THREE.Group();
  leftLeg.name = 'leftLeg';
  leftLeg.position.set(-0.15, 0.7, 0);
  const lLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.06, 0.6, 8), legMat);
  lLeg.position.y = -0.3;
  leftLeg.add(lLeg);
  group.add(leftLeg);

  const rightLeg = new THREE.Group();
  rightLeg.name = 'rightLeg';
  rightLeg.position.set(0.15, 0.7, 0);
  const rLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.06, 0.6, 8), legMat);
  rLeg.position.y = -0.3;
  rightLeg.add(rLeg);
  group.add(rightLeg);

  group.position.set(1, 0, 0.5);
  group.scale.set(0.85, 0.85, 0.85);
  return group;
}

function createParrot() {
  const group = new THREE.Group();
  group.userData = { type: 'parrot', baseY: 3, baseX: 2 };

  // Body (colorful)
  const body = new THREE.Mesh(
    new THREE.SphereGeometry(0.2, 12, 12),
    new THREE.MeshStandardMaterial({ color: 0x00CC44 })
  );
  body.scale.set(0.8, 1.2, 0.7);
  group.add(body);

  // Head
  const headGroup = new THREE.Group();
  headGroup.name = 'head';
  headGroup.position.y = 0.3;

  const pHead = new THREE.Mesh(
    new THREE.SphereGeometry(0.12, 10, 10),
    new THREE.MeshStandardMaterial({ color: 0x00CC44 })
  );
  headGroup.add(pHead);

  // Beak
  const beak = new THREE.Mesh(
    new THREE.ConeGeometry(0.05, 0.12, 6),
    new THREE.MeshStandardMaterial({ color: 0xFF8800 })
  );
  beak.position.set(0, -0.02, 0.12);
  beak.rotation.x = -Math.PI / 2;
  headGroup.add(beak);

  // Eyes
  const pEye = new THREE.Mesh(
    new THREE.SphereGeometry(0.025, 6, 6),
    new THREE.MeshStandardMaterial({ color: 0x111111 })
  );
  pEye.position.set(-0.06, 0.03, 0.09);
  headGroup.add(pEye);
  const pEye2 = pEye.clone();
  pEye2.position.set(0.06, 0.03, 0.09);
  headGroup.add(pEye2);

  // Red crest
  const crest = new THREE.Mesh(
    new THREE.ConeGeometry(0.04, 0.1, 6),
    new THREE.MeshStandardMaterial({ color: 0xFF0000 })
  );
  crest.position.set(0, 0.12, 0);
  headGroup.add(crest);

  group.add(headGroup);

  // Wings
  const wingMat = new THREE.MeshStandardMaterial({ color: 0x0088FF });
  const leftWing = new THREE.Group();
  leftWing.name = 'leftWing';
  leftWing.position.set(-0.18, 0.05, 0);
  const lW = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.08, 0.15), wingMat);
  lW.position.x = -0.12;
  leftWing.add(lW);
  group.add(leftWing);

  const rightWing = new THREE.Group();
  rightWing.name = 'rightWing';
  rightWing.position.set(0.18, 0.05, 0);
  const rW = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.08, 0.15), wingMat);
  rW.position.x = 0.12;
  rightWing.add(rW);
  group.add(rightWing);

  // Tail feathers
  const tailMat = new THREE.MeshStandardMaterial({ color: 0xFF4444 });
  const tail = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, 0.3), tailMat);
  tail.position.set(0, -0.1, -0.25);
  group.add(tail);

  const tailYellow = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.03, 0.25), new THREE.MeshStandardMaterial({ color: 0xFFDD00 }));
  tailYellow.position.set(0.04, -0.11, -0.2);
  group.add(tailYellow);

  group.position.set(2, 3, 0.5);
  group.scale.set(1.2, 1.2, 1.2);
  return group;
}

function createMonster() {
  const group = new THREE.Group();
  group.userData = { type: 'monster', baseY: -1 };

  // Large body
  const body = new THREE.Mesh(
    new THREE.SphereGeometry(2, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0x44AACC, roughness: 0.4 })
  );
  body.scale.set(1, 0.8, 0.9);
  group.add(body);

  // Head
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.8, 12, 12),
    new THREE.MeshStandardMaterial({ color: 0x55BBDD })
  );
  head.position.set(0, 1.8, 1);
  group.add(head);

  // Eyes (friendly big eyes)
  const eyeWhite = new THREE.MeshStandardMaterial({ color: 0xFFFFFF });
  const lEye = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 10), eyeWhite);
  lEye.position.set(-0.3, 2.0, 1.6);
  group.add(lEye);
  const rEye = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 10), eyeWhite);
  rEye.position.set(0.3, 2.0, 1.6);
  group.add(rEye);

  const pupilMat = new THREE.MeshStandardMaterial({ color: 0x222266 });
  const lP = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), pupilMat);
  lP.position.set(-0.3, 2.0, 1.75);
  group.add(lP);
  const rP = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), pupilMat);
  rP.position.set(0.3, 2.0, 1.75);
  group.add(rP);

  // Spots
  const spotMat = new THREE.MeshStandardMaterial({ color: 0x33CC99 });
  for (let i = 0; i < 8; i++) {
    const spot = new THREE.Mesh(new THREE.SphereGeometry(0.15 + Math.random() * 0.1, 8, 8), spotMat);
    spot.position.set(
      (Math.random() - 0.5) * 3,
      (Math.random() - 0.5) * 1.5,
      (Math.random() - 0.5) * 2
    );
    group.add(spot);
  }

  // Fins
  const finMat = new THREE.MeshStandardMaterial({ color: 0x3399AA });
  const topFin = new THREE.Mesh(new THREE.ConeGeometry(0.3, 1, 6), finMat);
  topFin.position.set(0, 2.5, 0);
  group.add(topFin);

  const leftFin = new THREE.Mesh(new THREE.BoxGeometry(1, 0.1, 0.5), finMat);
  leftFin.position.set(-2, 0, 0);
  leftFin.rotation.z = -0.3;
  group.add(leftFin);

  const rightFin = new THREE.Mesh(new THREE.BoxGeometry(1, 0.1, 0.5), finMat);
  rightFin.position.set(2, 0, 0);
  rightFin.rotation.z = 0.3;
  group.add(rightFin);

  group.position.set(0, -1, -5);
  return group;
}

function createGuardian() {
  const group = new THREE.Group();
  group.userData = { type: 'guardian', baseY: 0 };

  // Mysterious cloaked figure
  const cloak = new THREE.Mesh(
    new THREE.ConeGeometry(0.6, 2.5, 8),
    new THREE.MeshStandardMaterial({ color: 0x442288, emissive: 0x221144, emissiveIntensity: 0.3 })
  );
  cloak.position.y = 1.25;
  group.add(cloak);

  // Head (floating mask)
  const mask = new THREE.Mesh(
    new THREE.BoxGeometry(0.4, 0.5, 0.15),
    new THREE.MeshStandardMaterial({ color: 0xFFD700, metalness: 0.9, roughness: 0.1 })
  );
  mask.position.y = 2.7;
  group.add(mask);

  // Glowing eyes
  const glowMat = new THREE.MeshStandardMaterial({ color: 0x00FF88, emissive: 0x00FF88, emissiveIntensity: 1.0 });
  const lGlow = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), glowMat);
  lGlow.position.set(-0.1, 2.75, 0.1);
  group.add(lGlow);
  const rGlow = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), glowMat);
  rGlow.position.set(0.1, 2.75, 0.1);
  group.add(rGlow);

  // Staff
  const staff = new THREE.Mesh(
    new THREE.CylinderGeometry(0.03, 0.03, 2.5, 8),
    new THREE.MeshStandardMaterial({ color: 0x886600 })
  );
  staff.position.set(0.5, 1.25, 0);
  group.add(staff);

  // Staff orb
  const orb = new THREE.Mesh(
    new THREE.SphereGeometry(0.1, 10, 10),
    new THREE.MeshStandardMaterial({ color: 0xFFD700, emissive: 0xFFAA00, emissiveIntensity: 0.5 })
  );
  orb.position.set(0.5, 2.6, 0);
  group.add(orb);

  group.position.set(0, 0, -3);
  return group;
}

function createCharacters() {
  return {
    captain: createCaptain(),
    bobby: createBobby(),
    parrot: createParrot(),
    monster: createMonster(),
    guardian: createGuardian(),
  };
}

module.exports = { createCharacters };
